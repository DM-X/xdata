#include <math.h>
#include <ctype.h>
#include <dirent.h>
#include "xdata.h"

//------------------------------------------------------------------------------
int  InitXdata(xset_t* s, const char* xpath)
{
   strcpy(s->path_data, xpath);
   //sprintf(s->path_data, "/home/daniel/Dropbox/xdata");
   char path[PATH_LEN+PATH_EXTRA];
   DIR* dir;
   char file_name[PATH_LEN];
   int nbr_c, nbr_r;

   //I initialisation
   printf("initialize I:       ");
   sprintf(path, "%s/I", s->path_data);
   dir = opendir(path);
   if (dir) sprintf(file_name, "%s/ion.dat", path);
   else {printf("ERR: cannot find %s\n", path); return 1;}
   s->fp_I = fopen(file_name, "r");
   if (s->fp_I==NULL) {printf("ERR: cannot open %s\n", file_name); return 1;}
   GetTableSize(s->fp_I, &nbr_r, &nbr_c, 4096);
   s->len_I_Z = (nbr_c+1)/2;
   s->len_I_d = nbr_r;
   closedir(dir);
   printf("Z=1..%3d len=%d\n", s->len_I_Z-1, s->len_I_d);

   //F initialisation
   printf("initialize F:       ");
   sprintf(path, "%s/F", s->path_data);
   dir = opendir(path);
   if (dir) sprintf(file_name, "%s/F.dat", path);
   else {printf("ERR: cannot find %s\n", path); return 1;}
   s->fp_F = fopen(file_name, "r");
   if (s->fp_F==NULL) {printf("ERR: cannot open %s\n", file_name); return 1;}
   GetTableSize(s->fp_F, &nbr_r, &nbr_c, 4096);
   s->len_F_Z = (nbr_c+1)/2;
   s->len_F_d = nbr_r;
   s->len_Fcsp_d = nbr_r;
   closedir(dir);
   printf("Z=0..%3d len=%d\n", s->len_F_Z-1, s->len_F_d);

   //S initialisation
   printf("initialize S:       ");
   sprintf(path, "%s/S", s->path_data);
   dir = opendir(path);
   if (dir) sprintf(file_name, "%s/S.dat", path);
   else {printf("ERR: cannot find %s\n", path); return 1;}
   s->fp_S = fopen(file_name, "r");
   if (s->fp_S==NULL) {printf("ERR: cannot open %s\n", file_name); return 1;}
   GetTableSize(s->fp_S, &nbr_r, &nbr_c, 4096);
   s->len_S_Z = (nbr_c+1)/2;
   s->len_S_d = nbr_r;
   s->len_Scsp_d = nbr_r;
   closedir(dir);
   printf("Z=0..%3d len=%d\n", s->len_S_Z-1, s->len_S_d);

   //J initialisation
   printf("initialize J:       ");
   sprintf(path, "%s/J", s->path_data);
   dir = opendir(path);
   if (dir) sprintf(file_name, "%s/J.dat", path);
   else {printf("ERR: cannot find %s\n", path); return 1;}
   s->fp_J = fopen(file_name, "r");
   if (s->fp_J==NULL) {printf("ERR: cannot open %s\n", file_name); return 1;}
   GetTableSize(s->fp_J, &nbr_r, &nbr_c, 32000);
   s->len_J_Z = 103;
   s->len_J_d = nbr_r-2;
   s->len_Jcsp_d = 31;
   closedir(dir);
   printf("Z=0..%3d len=%d\n", s->len_J_Z-1, s->len_J_d);

   //atomic weight initialisation
   printf("initialize A:       ");
   sprintf(path, "%s/A", s->path_data);
   dir = opendir(path);
   if (dir) sprintf(file_name, "%s/atomic_weight.dat", path);
   else {printf("ERR: cannot find %s\n", path); return 1;}
   s->fp_am = fopen(file_name, "r");
   if (s->fp_am==NULL) {printf("ERR: cannot open %s\n", file_name); return 1;}
   GetTableSize(s->fp_am, &nbr_r, &nbr_c, 4096);
   s->len_am_Z = nbr_r + 1;
   s->len_am_d = 1;
   closedir(dir);
   printf("Z=1..%3d len=%d\n", s->len_am_Z-1, s->len_am_d);

   //rho initialisation
   printf("initialize rho:     ");
   sprintf(path, "%s/rho", s->path_data);
   dir = opendir(path);
   if (dir) sprintf(file_name, "%s/rho.dat", path);
   else {printf("ERR: cannot find %s\n", path); return 1;}
   s->fp_rho = fopen(file_name, "r");
   if (s->fp_rho==NULL) {printf("ERR: cannot open %s\n", file_name); return 1;}
   GetTableSize(s->fp_rho, &nbr_r, &nbr_c, 4096);
   s->len_rho_Z = nbr_r + 1;
   s->len_rho_d = 1;
   closedir(dir);
   printf("Z=1..%3d len=%d\n", s->len_rho_Z-1, s->len_rho_d);

   //rho compound initialisation
   printf("initialize rhoComp: ");
   sprintf(path, "%s/rho", s->path_data);
   dir = opendir(path);
   if (dir) sprintf(file_name, "%s/rhoComp.txt", path);
   else {printf("ERR: cannot find %s\n", path); return 1;}
   s->fp_rhoC = fopen(file_name, "r");
   if (s->fp_rhoC==NULL) {printf("ERR: cannot open %s\n", file_name); return 1;}
   GetTableSize(s->fp_rhoC, &nbr_r, &nbr_c, 4096);
   s->len_rhoC_comp = nbr_r + 1;
   s->len_rhoC_d    = 1;
   closedir(dir);
   printf("#=1..%3d len=%d\n", s->len_rhoC_comp-1, s->len_rhoC_d);

   //rho mixture initialisation
   printf("initialize rhoMix:  ");
   sprintf(path, "%s/rho", s->path_data);
   dir = opendir(path);
   if (dir) sprintf(file_name, "%s/rhoMix.txt", path);
   else {printf("ERR: cannot find %s\n", path); return 1;}
   s->fp_rhoM = fopen(file_name, "r");
   if (s->fp_rhoM==NULL) {printf("ERR: cannot open %s\n", file_name); return 1;}
   GetTableSize(s->fp_rhoM, &nbr_r, &nbr_c, 4096);
   s->len_rhoM_comp = nbr_r + 1;
   s->len_rhoM_d    = 1;
   closedir(dir);
   printf("#=1..%3d len=%d\n", s->len_rhoM_comp-1, s->len_rhoM_d);

   //mu/rho initialisation
   FILE* fp_test;
   int z;
   printf("initialize mu/rho:  ");
   sprintf(path, "%s/mudr", s->path_data);
   dir = opendir(path);
   if (!dir) {printf("ERR: cannot find %s\n", path); return 1;}
   for (z=1; z<=MU_Z_MAX; ++z) {
      sprintf(file_name, "%s/%03d_%s.txt", path, z, zToEl(z));
      fp_test = fopen(file_name, "r");
      if (fp_test==NULL) {printf("ERR: opening %s\n", file_name); return 1;}
      GetTableSize(fp_test, &nbr_r, &nbr_c, 4096);
      (s->len_mu_d)[z] = nbr_r;
      fclose(fp_test);
   }
   s->len_mu_Z  = MU_Z_MAX+1; //z=0 is not used
   s->len_mu_ia = NBR_IA+1;
   closedir(dir);
   printf("Z=0..%3d len[1..%d] = %d..%d\n", s->len_mu_Z-1, s->len_mu_Z-1,
          (s->len_mu_d)[1], (s->len_mu_d)[s->len_mu_Z-1]);

   //mu/rho_csp initialisation
   int ia;
   printf("initialize mu_csp:  ");
   sprintf(path, "%s/mudr", s->path_data);
   dir = opendir(path);
   if (!dir) {printf("ERR: cannot find %s\n", path); return 1;}
   for (z=1; z<=MU_Z_MAX; ++z) {
      for (ia=0; ia<=NBR_IA-1; ++ia) {
         sprintf(file_name, "%s/%03d_%s_%s.csp", path,z,zToEl(z),iaToStr(ia+2));
         fp_test = fopen(file_name, "r");
         if (fp_test==NULL) {printf("ERR: opening %s\n", file_name); return 1;}
         GetTableSize(fp_test, &nbr_r, &nbr_c, 4096);
         (s->len_mucsp_d)[z] = nbr_r;
         fclose(fp_test);
      }
   }
   s->len_mucsp_Z  = MU_Z_MAX+1; //z=0 is not used
   s->len_mucsp_ia = NBR_IA+1;
   closedir(dir);
   printf("Z=0..%3d len[1..%d] = %d..%d\n", s->len_mucsp_Z-1, s->len_mucsp_Z-1,
          (s->len_mucsp_d)[1], (s->len_mucsp_d)[s->len_mucsp_Z-1]);

   return 0;
}
//------------------------------------------------------------------------------
int GetTableSize(FILE* fp_dat, int* rows, int* cols, int size)
{
   rewind(fp_dat);
   int   first=1;
   int   row_cnt=0;
   int   col_cnt, last_col_cnt;
   char* line;
   line = (char*) malloc(size * sizeof(char));
   if (line==NULL) {printf("ERR: alloc. line\n"); return 1;}
   char* token;
   while (fgets(line, size, fp_dat)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         col_cnt = 0;
         token = strtok (line," ");
         while (token != NULL) {//go along one row (right)...
            ++col_cnt;
            if (EOL(token)) --col_cnt;
            token = strtok (NULL, " \n");
         }
         if (!first && (col_cnt!=last_col_cnt) && (col_cnt!=0)) {
            printf("ERR: unequal col numbers in GetTableSize():\n");
            printf("row = %d: %d != %d\n", row_cnt+1, last_col_cnt, col_cnt);
            free(line);
            return 1;
         }
         last_col_cnt = col_cnt;
         first=0;
         if (col_cnt!=0) ++row_cnt;
      }
   }
   *rows = row_cnt;
   *cols = col_cnt;
   free(line);
   return 0;
}
//------------------------------------------------------------------------------
//isolated \n-character (spaces at the end of line)
int EOL(char* token)
{
   int len = strlen(token);
   if (len==1) {
      if ((token[0]==10) || (token[0]==13)) return 1;
   } 
   if (len==2) {
      if ((token[0]==13) && (token[1]==10)) return 1;
   }

   return 0;
}
//------------------------------------------------------------------------------
int GetMix(const char* name, mix_t* mix, int* nbr, xset_t* s)
{
   char path[PATH_LEN+PATH_EXTRA];
   sprintf(path, "%s/mix", s->path_data);
   char file_name[PATH_LEN];
   sprintf(file_name, "%s/mixtures.txt", path);
   FILE* fp_dat = fopen(file_name, "r");
   if (fp_dat==NULL) {printf("ERR: cannot open %s\n", file_name); return 1;}

   int nbr_el = GetNbrEl(fp_dat, name);
   printf("nbr_el=%d\n", nbr_el);

   strcpy((*mix).name, name);
   (*mix).nbr    = nbr_el;
   (*mix).z_list = (int*)    malloc(nbr_el * sizeof(int));
   (*mix).m_frac = (double*) malloc(nbr_el * sizeof(double));
   if ((*mix).z_list==NULL) {printf("ERR: alloc mix.x_list\n"); return 1;}
   if ((*mix).m_frac==NULL) {printf("ERR: alloc mix.m_frac\n"); return 1;}

   GetMixEl(fp_dat, name, mix);

   //normalization:
   double mf_tot=0.0;
   int i;
   for (i=0; i<=nbr_el-1; ++i) {
      mf_tot += (mix->m_frac)[i];
   }
   if (mf_tot != 1.0) {
      printf("WAR: mixture %s: total mass fraction != 1 (%f)\n", name, mf_tot);
      printf("     conduct renormalization...\n");
      for (i=0; i<=nbr_el-1; ++i) {
         (mix->m_frac)[i] /= mf_tot;
      }
   }

   if (nbr!=NULL) *nbr = nbr_el;
   fclose(fp_dat);
   return 0;
}
//------------------------------------------------------------------------------
int GetMixEl(FILE* fp, const char* name_search, mix_t* mix)
{
   rewind(fp);
   char   line[256];
   char   name_read[256];
   int    cnt_started=0;
   int    nbr_read;
   int    cnt=0;
   int    z;
   double mf;

   while (fgets(line, 256, fp)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         nbr_read = sscanf(line, "%s %d %lf", name_read, &z, &mf);
         if (nbr_read!=3) return 0;
         else {
            if (cnt_started) {
               if (!strcmp(name_read, "-")) {
                  (mix->z_list)[cnt] = z;
                  (mix->m_frac)[cnt] = mf; 
                  ++cnt;
               }
               else return cnt; //next element reached
            }
            if (!strcmp(name_read, name_search)) {
               (mix->z_list)[cnt] = z;
               (mix->m_frac)[cnt] = mf; 
               cnt_started = 1;
               cnt = 1;
            }
         }
      }
   }
   return cnt;
}
//------------------------------------------------------------------------------
int GetNbrEl(FILE* fp, const char* name_search)
{
   rewind(fp);
   char  line[256];
   char  name_read[256];
   int   cnt_started=0;
   int   nbr_read;
   int   cnt=0;

   while (fgets(line, 256, fp)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         nbr_read = sscanf(line, "%s %*d %*f", name_read);
         if (nbr_read!=1) return 0;
         else {
            if (cnt_started) {
               if (!strcmp(name_read, "-")) ++cnt;
               else return cnt;
            }
            if (!strcmp(name_read, name_search)) {
               cnt_started = 1;
               cnt = 1;
            }
         }
      }
   }
   return cnt; //if last mixture is read
}
//------------------------------------------------------------------------------
int GetJ(double**** J_list, int** ns, int*** ne, double*** be,
         int* nbr_z, int* nbr_d, xset_t* s)
{
   FILE* fp_dat = s->fp_J;
   rewind(fp_dat);

   int n_data = s->len_J_d;
   int n_z    = s->len_J_Z; //col 0 is used for Q-values in J lists
   int z, si, c;

   *ns = (int*) malloc(n_z * sizeof(int)); //number of shells
   if (*ns==NULL) {printf("ERR: alloc nss_list\n"); return 1;}
   FillNumberOfShellList(ns);
   
   *J_list = (double***) malloc(n_z * sizeof(double**));
   if (*J_list==NULL) {printf("ERR: alloc J_list\n"); return 1;}
   for (z=0; z<=n_z-1; ++z) {
      (*J_list)[z] = (double**) malloc(((*ns)[z]+1)* sizeof(double*));
      if ((*J_list)[z]==NULL) {printf("ERR: alloc J_list\n"); return 1;}
      for (si=0; si<=(*ns)[z]; ++si) { 
         (*J_list)[z][si] = (double*) malloc(n_data * sizeof(double));
         if ((*J_list)[z][si]==NULL) {printf("ERR: alloc J_list\n"); return 1;}
      }
   }

   (*ne) = (int**) malloc(n_z * sizeof(int*));//nbr el in shell [z:1.102][si:1.]
   if ((*ne) == NULL) {printf("ERR: alloc ne\n"); return 1;}
   for (z=0; z<=n_z-1; ++z) {
      (*ne)[z] = (int*) calloc(((*ns)[z]+1), sizeof(int));
      if ((*ne)[z] == NULL) {printf("ERR: alloc ne\n"); return 1;}
   }

   (*be) = (double**) malloc(n_z*sizeof(double*));//binding erg [z:1.102][si:1.]
   if ((*be) == NULL) {printf("ERR: alloc be\n"); return 1;}
   for (z=0; z<=n_z-1; ++z) {
      (*be)[z] = (double*) calloc(((*ns)[z]+1), sizeof(double));
      if ((*be)[z] == NULL) {printf("ERR: alloc be\n"); return 1;}
   }

   char*  line;
   int    line_max = 32768;
   line  = (char*) malloc(line_max * sizeof(char));
   if (line==NULL) {printf("ERR: alloc. line\n"); return 1;}
   char* token;
   int   row_cnt=0;
   while (fgets(line, line_max, fp_dat)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         c=0;            //column index
         si=0;           //shell index
         z=1;            //atomic nbr
         token = strtok (line," ");

         if (row_cnt <= n_data-1) {//Compton profiles
            while (token != NULL) {//go along one row (right)...
               if (z == n_z) break;
               if (c==0) {
                  (*J_list)[0][0][row_cnt] = atof(token);
               } else {
                  if (1<=si && si<=(*ns)[z]+1) {
                     if (si==(*ns)[z]+1) (*J_list)[z][0][row_cnt] = atof(token);
                     else (*J_list)[z][si][row_cnt] = atof(token);
                  }
               }
               token = strtok (NULL, " ");
               if (si>=(*ns)[z]+1) {
                  si=0;
                  ++z;
               } else ++si;
               ++c;
            }
         }

         if (row_cnt == n_data) {//binding energies
            while (token != NULL) {//go along one row (right)...
               if (z == n_z) break;
               if (1<=si && si<=(*ns)[z]) {
                  if (!strcmp(token, "-"))
                     printf("ERR in tab: token=%s, c=%d, si=%d\n", token, c,si);
                  (*be)[z][si] = atof(token) * 0.001;
               }
               token = strtok (NULL, " ");
               if (si>=(*ns)[z]+1) {
                  si=0;
                  ++z;
               } else ++si;
               ++c;
            }
         }

         if (row_cnt == n_data+1) {//number of electrons
            while (token != NULL) {//go along one row (right)...
               if (z == n_z) break;
               if (1<=si && si<=(*ns)[z]) {
                  if (!strcmp(token, "-"))
                     printf("ERR in tab: token=%s c=%d si=%d\n", token, c, si);
                  (*ne)[z][si] = atoi(token);
               }
               token = strtok (NULL, " ");
               if (si>=(*ns)[z]+1) {
                  si=0;
                  ++z;
               } else ++si;
               ++c;
            }
         }

         if (row_cnt >= n_data+2) {
            printf("ERR: J: %d>=%d\n", row_cnt, n_data+2);
            break; //while
         }

         ++row_cnt;
      }
   }

   if (nbr_z!=NULL) *nbr_z = n_z;
   if (nbr_d!=NULL) *nbr_d = n_data;
   free(line);
   return 0;
}
//------------------------------------------------------------------------------
void FillNumberOfShellList(int** ns)
{
   (*ns)[0] =1;  //fake: stores the list of Q-values
   (*ns)[1] =1;  //Z=1 has 1 shell
   (*ns)[2] =1;  //Z=2 has 1 shell
   (*ns)[3] =2;  //Z=3 has 2 shells ...
   (*ns)[4] =2;
   (*ns)[5] =3;
   (*ns)[6] =3;
   (*ns)[7] =3;
   (*ns)[8] =3;
   (*ns)[9] =3;

   (*ns)[10]=3;   (*ns)[20]=6;   (*ns)[30]= 7;   (*ns)[40]=14;   (*ns)[50]=16;
   (*ns)[11]=4;   (*ns)[21]=7;   (*ns)[31]= 8;   (*ns)[41]=14;   (*ns)[51]=17;
   (*ns)[12]=4;   (*ns)[22]=7;   (*ns)[32]= 8;   (*ns)[42]=15;   (*ns)[52]=17;
   (*ns)[13]=5;   (*ns)[23]=7;   (*ns)[33]= 8;   (*ns)[43]=15;   (*ns)[53]=17;
   (*ns)[14]=5;   (*ns)[24]=7;   (*ns)[34]= 8;   (*ns)[44]=15;   (*ns)[54]=17;
   (*ns)[15]=5;   (*ns)[25]=7;   (*ns)[35]= 8;   (*ns)[45]=15;   (*ns)[55]=18;
   (*ns)[16]=5;   (*ns)[26]=7;   (*ns)[36]=12;   (*ns)[46]=14;   (*ns)[56]=18;
   (*ns)[17]=5;   (*ns)[27]=7;   (*ns)[37]=13;   (*ns)[47]=15;   (*ns)[57]=19;
   (*ns)[18]=5;   (*ns)[28]=7;   (*ns)[38]=13;   (*ns)[48]=15;   (*ns)[58]=20;
   (*ns)[19]=6;   (*ns)[29]=7;   (*ns)[39]=14;   (*ns)[49]=16;   (*ns)[59]=19;

   (*ns)[60]=19;  (*ns)[70]=20;  (*ns)[80]=22;   (*ns)[90]=26;   (*ns)[100]=27;
   (*ns)[61]=19;  (*ns)[71]=21;  (*ns)[81]=23;   (*ns)[91]=27;   (*ns)[101]=27;
   (*ns)[62]=19;  (*ns)[72]=21;  (*ns)[82]=23;   (*ns)[92]=27;   (*ns)[102]=27;
   (*ns)[63]=20;  (*ns)[73]=21;  (*ns)[83]=24;   (*ns)[93]=27;
   (*ns)[64]=21;  (*ns)[74]=21;  (*ns)[84]=24;   (*ns)[94]=26;
   (*ns)[65]=20;  (*ns)[75]=22;  (*ns)[85]=24;   (*ns)[95]=27;
   (*ns)[66]=20;  (*ns)[76]=22;  (*ns)[86]=24;   (*ns)[96]=28;
   (*ns)[67]=20;  (*ns)[77]=22;  (*ns)[87]=25;   (*ns)[97]=27;
   (*ns)[68]=20;  (*ns)[78]=22;  (*ns)[88]=25;   (*ns)[98]=27;
   (*ns)[69]=20;  (*ns)[79]=22;  (*ns)[89]=26;   (*ns)[99]=27;
}
//------------------------------------------------------------------------------
void PrintMudr(mudr_t* mdr, double erg_a, double erg_b)
{
   int ia;
   int nbr_ia = (*mdr).len_c;
   printf("\n--- MASS ATTENUATION COEFFICIENT mu/rho ---\n");
   printf("z=%3d:\n", (*mdr).z);
   printf("erg       coh.      inc.      PE        pair_n    ");
   printf("pair_a    tot       tot-coh\n");
   printf("[keV]     [cm^2/g]  [cm^2/g]  [cm^2/g]  [cm^2/g]   ");
   printf("[cm^2/g]  [cm^2/g]  [cm^2/g]\n");
   int id;
   int nbr_id = (*mdr).len_d;

   if (erg_b<0) {  //stoping energy is not set
      erg_b=1E200; //arbitrary large
   }

   for (id=0; id<=nbr_id-1; ++id) {
      if ((((*mdr).mudr)[0][id] >= erg_a) && (((*mdr).mudr)[0][id] <= erg_b)) {
         for (ia=0; ia<=nbr_ia-1; ++ia) {
            printf("%5.3E ", ((*mdr).mudr)[ia][id]);
         }
         printf("\n");
      }
   }
}
//------------------------------------------------------------------------------
void PrintJ(double*** J_list, int* ns, int** ne, double** be, const char* z_str,
            xset_t* s)
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return;}
   int r;  //row index
   int si; //shell index
   int nbr_r = s->len_J_d;
   printf("\n--- COMPTON PROFILE J with all subshells ---\n");
   printf("z=%3d:\n", z);
   printf("Q           TOTAL       shell_1 ...\n");
   for (r=0; r<=nbr_r-1; ++r) {
      printf("%4.2E", J_list[0][0][r]);
      for (si=0; si<=ns[z]; ++si) {
         printf("    %4.2E", J_list[z][si][r]);
      }
      printf("\n");
   }
   printf("--");
   for (si=0; si<=ns[z]; ++si) printf("--------------");
   printf("\nbe [keV]:");
   for (si=0; si<=ns[z]; ++si) {
      printf("   %4.2E ", be[z][si]);
   }
   printf("\nne [#]: ");
   for (si=0; si<=ns[z]; ++si) {
      printf("          %2d", ne[z][si]);
   }
   printf("\n");
}
//------------------------------------------------------------------------------
void PrintMudrCsp(iac_t* iac)
{
   int i;
   int z = (*iac).z;
   int length = iac->len;
   csp_t* mu_list = (*iac).cspl;
   printf("\n--- MASS ATTENUATION COEFFICIENT mu/rho CSP ---\n");
   printf("z = %d (%s),  type = %s:\n", z, zToEl(z), (*iac).type);
   printf("#lin: mu/rho = a[n] + b[n]*dx + c[n]*dx^2 + d[n]*dx^3\n");
   printf("#with dx=x-x0[n-1]\n");
   printf("#log: mu/rho = exp(a[n] + b[n]*dx + c[n]*dx^2 + d[n]*dx^3)\n");
   printf("#with dx=log(x)-log(x0[n-1])\n");
   printf("#mu/rho in units of cm^2/g\n");
   printf("x            a          b          c           d          type\n");
   printf("[keV]        []         []         []          []         []\n");
   printf("%5.3E   %+5.3E      %+5.3E      %+5.4E       %+5.3E       %s\n",
          mu_list[0].x, mu_list[0].a, mu_list[0].b, 
          mu_list[0].c, mu_list[0].d, mu_list[0].type);
   for (i=1; i<=length-1; ++i) {
      printf("%5.3E %+5.3E %+5.3E %+5.4E %+5.3E   %s\n",
            mu_list[i].x, mu_list[i].a, mu_list[i].b,
            mu_list[i].c, mu_list[i].d, mu_list[i].type);
   }
}
//------------------------------------------------------------------------------
double CalcF(fs_t* f_fact, double erg, double theta)
{
   int length = f_fact->len;
   double x = sin(theta/180*M_PI / 2.0) * erg/12.3984193; //kev / (keV Angstrom)
   return CalcCSI((*f_fact).cspl, x, length);
}
//------------------------------------------------------------------------------
double CalcS(fs_t* s_fact, double erg, double theta)
{
   int length = s_fact->len;
   double x = sin(theta/180*M_PI / 2.0) * erg/12.3984193; //kev / (keV Angstrom)
   return CalcCSI((*s_fact).cspl, x, length);
}
//------------------------------------------------------------------------------
void MakeJTotalComp(acp_t* Jtot, xset_t* s, int n, ...)
{ 
   int nbr_el = n;// number of elements
   int ratio_list[nbr_el];
   int z_list[nbr_el];

   va_list valist;
   n*=2; //there are two variables (element_string, element_ratio) for each el.
   va_start(valist, n);
   ExtractCompArgs(valist, n, z_list, ratio_list);
   va_end(valist);

   //Get data
   double*** J_list;    //[z][shell][data]
   int*      ns;        //nbr of shells [z:1..102] 
   int**     ne;        //nbr el in shell [z:1.102][shell:1..ns[z]]
   double**  be;        //binding energ [z:1..102][shell:1..ns[z]]
   GetJ(&J_list, &ns, &ne, &be, NULL, NULL, s);

   //Make shell lists
   jshell_t* shell_lists[nbr_el];
   int nbr_shells[nbr_el];
   int ie; //element index
   for (ie=0; ie<=nbr_el-1; ++ie) {
      MakeShellList(J_list, ns, ne, be, z_list[ie], s, 
                    &(shell_lists[ie]), &(nbr_shells[ie]));
   }

   //Make total shell list
   int total_nbr_shells;
   jshell_t* total_shell_list;
   int i;
   double ratio_list_db[nbr_el];
   for (i=0; i<=nbr_el-1; ++i) {
      ratio_list_db[i] = (double) ratio_list[i];
   }
   MakeCombShell(shell_lists, nbr_shells, ratio_list_db, nbr_el,
                 &total_shell_list, &total_nbr_shells);

   //Sort data  
   qsort(total_shell_list, total_nbr_shells, sizeof(jshell_t), jscompare);

   //Calc sums with E > E_binding
   CalcCumulativeJ(total_shell_list, total_nbr_shells);

   //Calc CSP
   Jtot->al = (atomic_t*) malloc((total_nbr_shells-1) * sizeof(atomic_t));
   if (Jtot->al == NULL) {printf("ERR: alloc Jtot->atomic list\n"); exit(1);}
   int is, len_csp;
   int length = (total_shell_list[0]).len;  //all have the same length
   for (is=0; is<=total_nbr_shells-2; ++is) {//J_tot is twice at is=0 and is=end
      ((Jtot->al)[is]).len = length;
      ((Jtot->al)[is]).erg = (total_shell_list[is+1]).erg;
      MakeCSP(J_list[0][0], (total_shell_list[is+1]).jl, length,
              &(((Jtot->al)[is]).cspl), &len_csp);
   }

   //Arrange output
   Jtot->z          = -1;
   Jtot->nbr_shells = total_nbr_shells-1;

   FreeJ(&J_list, &ns, &ne, &be, s);
   FreeCombShell(&total_shell_list, total_nbr_shells);
   for (ie=0; ie<=nbr_el-1; ++ie) {
      FreeShellList(&(shell_lists[ie]), nbr_shells[ie]);
   }
}
//------------------------------------------------------------------------------
void MakeJTotalMix(acp_t* Jtot, xset_t* s, mix_t* mix)
{ 

   int nbr_el = mix->nbr;// number of elements

   double* A_list;
   GetA(&A_list, NULL, s);

   double ratio_list_db[nbr_el];
   int i, z_el; 
   for (i=0; i<=nbr_el-1; ++i) {
      z_el = (mix->z_list)[i];
      ratio_list_db[i] = (mix->m_frac)[i] / A_list[z_el];
   }
   FreeA(&A_list);

   //Get data
   double*** J_list;    //[z][shell][data]
   int*      ns;        //nbr of shells [z:1..102] 
   int**     ne;        //nbr el in shell [z:1.102][shell:1..ns[z]]
   double**  be;        //binding energ [z:1..102][shell:1..ns[z]]
   GetJ(&J_list, &ns, &ne, &be, NULL, NULL, s);

   //Make shell lists
   jshell_t* shell_lists[nbr_el];
   int nbr_shells[nbr_el];
   int ie; //element index
   for (ie=0; ie<=nbr_el-1; ++ie) {
      MakeShellList(J_list, ns, ne, be, (mix->z_list)[ie], s, 
                    &(shell_lists[ie]), &(nbr_shells[ie]));
   }

   //Make total shell list
   int total_nbr_shells;
   jshell_t* total_shell_list;
   MakeCombShell(shell_lists, nbr_shells, ratio_list_db, nbr_el,
                 &total_shell_list, &total_nbr_shells);

   //Sort data  
   qsort(total_shell_list, total_nbr_shells, sizeof(jshell_t), jscompare);

   //Calc sums with E > E_binding
   CalcCumulativeJ(total_shell_list, total_nbr_shells);

   //Calc CSP
   Jtot->al = (atomic_t*) malloc((total_nbr_shells-1) * sizeof(atomic_t));
   if (Jtot->al == NULL) {printf("ERR: alloc Jtot->atomic list\n"); exit(1);}
   int is, len_csp;
   int length = (total_shell_list[0]).len;  //all have the same length
   for (is=0; is<=total_nbr_shells-2; ++is) { //J_tot is twice at is=0 and is=end
      ((Jtot->al)[is]).len = length;
      ((Jtot->al)[is]).erg = (total_shell_list[is+1]).erg;
      MakeCSP(J_list[0][0], (total_shell_list[is+1]).jl, length,
              &(((Jtot->al)[is]).cspl), &len_csp);
   }

   //Arrange output
   Jtot->z          = -1;
   Jtot->nbr_shells = total_nbr_shells-1;

   FreeJ(&J_list, &ns, &ne, &be, s);
   FreeCombShell(&total_shell_list, total_nbr_shells);
   for (ie=0; ie<=nbr_el-1; ++ie) {
      FreeShellList(&(shell_lists[ie]), nbr_shells[ie]);
   }
}
//------------------------------------------------------------------------------
void MakeCombShell(jshell_t** shell_lists, int* nbr_shells, double* ratio_list, 
                   int nbr_el, jshell_t** tot_s_list, int* total_nbr_shells)
{
   int ie, is, id;
   int ns_tot=0;
   double ratio_tot=0.0;
   for (ie=0; ie<=nbr_el-1; ++ie) {
      ns_tot += nbr_shells[ie];
      ratio_tot += ratio_list[ie];
   }
   ns_tot -= (nbr_el-1); //remove the multiple Jtot entries
   *total_nbr_shells = ns_tot;

   int length = (shell_lists[0][0]).len; //all lengths are equal
   *tot_s_list = (jshell_t*) malloc(ns_tot * sizeof(jshell_t));
   if (*tot_s_list==NULL) {printf("ERR: alloc tot_shell_list\n");exit(1);}
   for (is=0; is <= ns_tot-1; ++is) {
      ((*tot_s_list)[is]).jl = (double*) malloc(length * sizeof(double));
      if (is==0) { //at is=0 there will be the weighted sum of all J_tots
         for (id=0; id<=length-1; ++id) {
            (((*tot_s_list)[0]).jl)[id] = 0.0;
         }
      }
   }

   double weight_list[nbr_el];
   for (ie=0; ie<=nbr_el-1; ++ie) {
      weight_list[ie] = ratio_list[ie]/ratio_tot;
   }


   int is_tot = 0;
   for (ie=0; ie<=nbr_el-1; ++ie) {
      for (is=0; is<=nbr_shells[ie]-1; ++is) {
         ((*tot_s_list)[is_tot]).len    = length;
         ((*tot_s_list)[is_tot]).nbr_el = (shell_lists[ie][is]).nbr_el;
         ((*tot_s_list)[is_tot]).erg    = (shell_lists[ie][is]).erg;
         for (id=0; id<=length-1; ++id) {
            if (is==0) { 
               (((*tot_s_list)[0]).jl)[id] += 
                  weight_list[ie] * ((shell_lists[ie][is]).jl)[id];
            } else {
               (((*tot_s_list)[is_tot]).jl)[id] = 
                  weight_list[ie] * ((shell_lists[ie][is]).jl)[id];
            }
         }
         if (is==0 && is_tot!=0) --is_tot;
         ++is_tot;
      }
   }
   if (is_tot!=ns_tot) printf("ERR: is_tot != ns_tot\n");
}
//------------------------------------------------------------------------------
void MakeJTotal(acp_t* Jtot, const char* z_str, xset_t* s)
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return;}
   //Get data
   double*** J_list;    //[z][shell][data]
   int*      ns;        //nbr of shells [z:1..102] 
   int**     ne;        //nbr el in shell [z:1.102][shell:1..ns[z]]
   double**  be;        //binding energ [z:1..102][shell:1..ns[z]]
   GetJ(&J_list, &ns, &ne, &be, NULL, NULL, s);
   
   //Make shell list
   jshell_t* shell_list;
   int nbr_shells;
   MakeShellList(J_list, ns, ne, be, z, s, &shell_list, &nbr_shells);

   //Sort data  
   qsort(shell_list, nbr_shells, sizeof(jshell_t), jscompare);

   //Calc sums with E > E_binding
   CalcCumulativeJ(shell_list, nbr_shells);

   //Calc CSP
   Jtot->al = (atomic_t*) malloc((nbr_shells-1) * sizeof(atomic_t));
   if (Jtot->al == NULL) {printf("ERR: alloc Jtot->atomic list\n"); exit(1);}
   int is, len_csp;
   int length = (shell_list[0]).len;  //all have the same length
   for (is=0; is<=nbr_shells-2; ++is) { //J_tot is twice at is=0 and is=end
      ((Jtot->al)[is]).len = length;
      ((Jtot->al)[is]).erg = (shell_list[is+1]).erg;
      MakeCSP(J_list[0][0], (shell_list[is+1]).jl, length,
              &(((Jtot->al)[is]).cspl), &len_csp);
   }

   //Arrange output
   Jtot->z          = z;
   Jtot->nbr_shells = nbr_shells-1;

   FreeJ(&J_list, &ns, &ne, &be, s);
   FreeShellList(&shell_list, nbr_shells);
}
//------------------------------------------------------------------------------
void CalcCumulativeJ(jshell_t* shell_list, int nbr_shells)
{
   int n_el, is, id;
   int length;
   double val_old;
   double val_act;
   for (is=1; is<=nbr_shells-2; ++is) { //is=0 is J_tot, is=nbr_s-1 -> J_tot
      n_el   = (shell_list[is]).nbr_el;
      length = (shell_list[is]).len;
      for (id=0; id<=length-1; ++id) {
         val_act = ((shell_list[is]).jl)[id];
         if (is!=1) {
            val_old = ((shell_list[is-1]).jl)[id];
            ((shell_list[is]).jl)[id] = val_old + n_el*val_act;
         } else {
            ((shell_list[is]).jl)[id] = n_el*val_act;
         }
      }
   }

   //copy J_tot into last shell_list (to avoid rounding errors for summing)
   for (id=0; id<=length-1; ++id) {
      ((shell_list[is]).jl)[id] = ((shell_list[0]).jl)[id];
   }
}
//------------------------------------------------------------------------------
void MakeShellList(double*** J_list, int* ns, int** ne, double** be, int z, 
                   xset_t* s, jshell_t** shell_list, int* nbr_shells)
{
   int is, id;
   *nbr_shells = ns[z] + 1; //one more because of J_total is in s=0
   *shell_list = (jshell_t*) malloc(*nbr_shells * sizeof(jshell_t));
   if (*shell_list==NULL) {printf("ERR: alloc. shell_list\n"); exit(1);}
   int length = s->len_J_d;
   for (is=0; is <= *nbr_shells-1; ++is) {
      ((*shell_list)[is]).len    = length;
      ((*shell_list)[is]).nbr_el = ne[z][is];
      ((*shell_list)[is]).erg    = be[z][is];
      ((*shell_list)[is]).jl     = (double*) malloc(length * sizeof(double));
      for (id=0; id<=length-1; ++id) {
         (((*shell_list)[is]).jl)[id] = J_list[z][is][id];
      }
   }
}
//------------------------------------------------------------------------------
double CalcJTotal(acp_t* J, double E0, double theta, double E)
{
   int is;
   int length;
   int nbr_shells = J->nbr_shells;
   double dE = E0-E;
   double  Q = CalcQ(E0, theta, E);
   for (is=nbr_shells-1; is>=0; --is) {
      if (dE >= ((J->al)[is]).erg) {
         length = ((J->al)[is]).len;
         return CalcCSI(((J->al)[is]).cspl, Q, length);
      }
   }
   return 0.0;
}
//------------------------------------------------------------------------------
double CalcJShell(cprof_t* cprof, int shell, double E0, double theta, double E)
{
   if (shell >= cprof->nbr_shells) {
      printf("ERR: shell number %d too large (<%d)\n", shell,cprof->nbr_shells);
      return -1;
   }
   if (E0-E < ((cprof->sl)[shell]).erg) {
      printf("WAR: shell cannot contribute to J as E0-E < ionization energy\n");
      return 0.0;
   }
   double  Q  = CalcQ(E0, theta, E);
   int length = ((cprof->sl)[shell]).len;
   return CalcCSI(((cprof->sl)[shell]).cspl, Q, length);
}
//------------------------------------------------------------------------------
double CalcMudr(iac_t* iac, double erg)
{
   int length = iac->len;
   return CalcCSI((*iac).cspl, erg, length);
}
//------------------------------------------------------------------------------
double CalcCSI(csp_t* cspl, double x, int length)
{
   int i;
   int type_log; //1 = log, else = lin
   double a, b, c, d, dx, y;

   //check
   if (length <= 1) {
      printf("WAR: CSP table too short (%d)\n", length);
      return NAN;
   }
   if (x<0.0) {
      printf("WAR: negative energy value (%E)\n", x);
      return NAN;
   }

   //x is too small for csp table -> exptrapolation
   if (x < (cspl[0]).x) {
      a = (cspl[1]).a;
      b = (cspl[1]).b;
      c = 0.0;
      d = 0.0;
      type_log = !(strcmp((cspl[1]).type, "log"));
      if (type_log) dx = log(x) - log((cspl[0]).x); 
      else dx = x - (cspl[0]).x;

      y = a + b*dx + c*dx*dx + d*dx*dx*dx;
      if (type_log) return exp(y);
      else return y;
   }

   //x is within csp table
   for (i=1; i<=length-1; ++i) { //find corresponding csp for x
      if (x < (cspl[i]).x) {
         a = (cspl[i]).a;
         b = (cspl[i]).b;
         c = (cspl[i]).c;
         d = (cspl[i]).d;
         type_log = !(strcmp((cspl[i]).type, "log"));
         if (type_log) dx = log(x) - log((cspl[i-1]).x); 
         else dx = x - (cspl[i-1]).x; 

         y = a + b*dx + c*dx*dx + d*dx*dx*dx;
         if (type_log) return exp(y);
         else return y;
      }
   }

   //if this point is reached: x > last x in csp table
   i = length-1; //extrapolate linearly (c=d=0) from last csp table entry
   a = (cspl[i]).a;
   b = (cspl[i]).b;
   c = 0.0;
   d = 0.0;
   type_log = !(strcmp((cspl[i]).type, "log"));
   if (type_log) dx = log(x) - log((cspl[i-1]).x); 
   else dx = x - (cspl[i-1]).x;

   y = a + b*dx + c*dx*dx + d*dx*dx*dx;
   if (type_log) return exp(y);
   else return y;
}
//------------------------------------------------------------------------------
int CheckJ(double*** J_list, int* ns, int** ne, xset_t* s)
{
   int r;  //row index
   int si; //shell index
   int z;  //atiomic number
   int nbr_r = s->len_J_d;
   int nbr_z = s->len_J_Z;
   int sum_ne;
   int err_cnt=0;
   double Q;
   double sum_J;
   double tot;
   for (z=1; z<=nbr_z-1; ++z) {
      for (si=0; si<=ns[z]; ++si) {
         for (r=0; r<=nbr_r-2; ++r) {
            if (J_list[z][si][r] < J_list[z][si][r+1]) {
               if (r!=23)  //going from 2 to 1 decimal places -> can be asc.
               printf("J ascending: %E -> %E at z=%d s=%d r=%d\n",
                      J_list[z][si][r], J_list[z][si][r+1], z, si, r);
            }
         }
      }
   }

   for (z=1; z<=nbr_z-1; ++z) {
      for (r=0; r<=nbr_r-1; ++r) {
         sum_J  = 0.0;
         for (si=1; si<=ns[z]; ++si) {
            sum_J  += J_list[z][si][r] * ne[z][si];
         }
         tot = J_list[z][0][r];
         Q   = J_list[0][0][r];
         if (Q<9.99 && ((sum_J > 1.02*tot) || (sum_J < 0.98*tot))) {
            ++err_cnt;
            printf("inconsistency at Z=%d, Q=%5.2f: sum=%4.2E tot=%4.2E\n",
                   z, J_list[0][0][r], sum_J, tot);
         }
         if (Q>=9.99 && ((sum_J > 1.06*tot) || (sum_J < 0.94*tot))) {
            ++err_cnt;
            printf("inconsistency at Z=%d, Q=%5.2f: sum=%4.2E tot=%4.2E\n",
                   z, J_list[0][0][r], sum_J, tot);
         }
      }
      sum_ne = 0;
      for (si=1; si<=ns[z]; ++si) sum_ne += ne[z][si];
      if (sum_ne != z) {
         ++err_cnt;
         printf("nbr of el inconsistent: Z=%d, Q=%5.2f\n", z, J_list[0][0][r]);
      }
   }
   return err_cnt;
}
//------------------------------------------------------------------------------
int GetFCsp(fs_t* f_fact, const char* z_str, int* nbr_d, xset_t* s)
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return -1;}
   char path[PATH_LEN+PATH_EXTRA];
   sprintf(path, "%s/F", s->path_data);
   char file_name[PATH_LEN];
   sprintf(file_name, "%s/%03d_%s_F.csp", path, z, zToEl(z));
   FILE* fp_dat = fopen(file_name, "r");
   if (fp_dat==NULL) {printf("ERR: cannot open %s\n", file_name); exit(1);}

   int n_data = s->len_Fcsp_d;
   (*f_fact).z    = z;
   (*f_fact).len  = n_data;
   (*f_fact).cspl = (csp_t*) malloc(n_data * sizeof(csp_t));
   if ((*f_fact).cspl==NULL) {printf("ERR: alloc csp_list cprof\n"); return -1;}
   GetCsp(fp_dat, (*f_fact).cspl, n_data);

   if (nbr_d!=NULL) *nbr_d = n_data;
   fclose(fp_dat);
   return 0;
}
//------------------------------------------------------------------------------
int GetSCsp(fs_t* s_fact, const char* z_str, int* nbr_d, xset_t* s)
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return -1;}
   char path[PATH_LEN+PATH_EXTRA];
   sprintf(path, "%s/S", s->path_data);
   char file_name[PATH_LEN];
   sprintf(file_name, "%s/%03d_%s_S.csp", path, z, zToEl(z));
   FILE* fp_dat = fopen(file_name, "r");
   if (fp_dat==NULL) {printf("ERR: cannot open %s\n", file_name); exit(1);}

   int n_data = s->len_Scsp_d;
   (*s_fact).z    = z;
   (*s_fact).len  = n_data;
   (*s_fact).cspl = (csp_t*) malloc(n_data * sizeof(csp_t));
   if ((*s_fact).cspl==NULL) {printf("ERR: alloc csp_list cprof\n"); return -1;}
   GetCsp(fp_dat, (*s_fact).cspl, n_data);

   if (nbr_d!=NULL) *nbr_d = n_data;
   fclose(fp_dat);
   return 0;
}
//------------------------------------------------------------------------------
int GetJShells(cprof_t* cprof, const char* z_str, int* nbr_s, int* nbr_d, 
               xset_t* s)
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return -1;}
   double*** J_list;    //[z][shell][data]
   int*      ns;        //nbr of shells [z:1..102] 
   int**     ne;        //nbr el in shell [z:1.102][shell:1..ns[z]]
   double**  be;        //binding energ [z:1..102][shell:1..ns[z]]
   GetJ(&J_list, &ns, &ne, &be, NULL, NULL, s);

   int is, nbr_data;
   int nbr_shells=ns[z] + 1; //one more because of J_total is in s=0
   cprof->z     = z;
   cprof->nbr_shells = nbr_shells;

   cprof->sl = (shell_t*) malloc(nbr_shells * sizeof(shell_t));
   if (cprof->sl == NULL) {printf("ERR: alloc cprof->shell list\n"); return -1;}
   for (is=0; is<=nbr_shells-1; ++is) {
      FillJShell(&((cprof->sl)[is]), z_str, is, &ne, &be, &nbr_data, s);
   }

   if (nbr_s!=NULL) *nbr_s = nbr_shells;
   if (nbr_d!=NULL) *nbr_d = nbr_data;
   FreeJ(&J_list, &ns, &ne, &be, s);
   return 0;
}
//------------------------------------------------------------------------------
int FillJShell(shell_t* shell, const char* z_str, int shell_nbr, int*** ne,
               double*** be, int* nbr_d, xset_t* s)
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return -1;}
   char path[PATH_LEN+PATH_EXTRA];
   sprintf(path, "%s/J", s->path_data);
   char file_name[PATH_LEN];
   sprintf(file_name, "%s/%03d_%s_J%02d.csp", path, z, zToEl(z), shell_nbr);
   FILE* fp_dat = fopen(file_name, "r");
   if (fp_dat==NULL) {printf("ERR: cannot open %s\n", file_name); exit(1);}

   int n_data = s->len_Jcsp_d;
   shell->len    = n_data;
   shell->nbr_el = (*ne)[z][shell_nbr];
   shell->erg    = (*be)[z][shell_nbr];
   shell->cspl   = (csp_t*) malloc(n_data * sizeof(csp_t));
   if (shell->cspl==NULL) {printf("ERR: alloc shell->csp_list\n"); return -1;}

   GetCsp(fp_dat, shell->cspl, n_data);

   if (nbr_d!=NULL) *nbr_d = n_data;
   fclose(fp_dat);
   return 0;
}
//------------------------------------------------------------------------------
int GetMudrCsp(iac_t* iac, const char* z_str, char* ia_str,int* nbr_d,xset_t* s)
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return -1;}
   char path[PATH_LEN+PATH_EXTRA];
   sprintf(path, "%s/mudr", s->path_data);
   char file_name[PATH_LEN];
   sprintf(file_name, "%s/%03d_%s_%s.csp", path, z, zToEl(z), ia_str);
   FILE* fp_dat = fopen(file_name, "r");
   if (fp_dat==NULL) {printf("ERR: cannot open %s\n", file_name); exit(1);}

   int n_data = (s->len_mucsp_d)[z];
   strcpy((*iac).type, ia_str);
   (*iac).z    = z;
   (*iac).len  = n_data;
   (*iac).cspl = (csp_t*) malloc(n_data * sizeof(csp_t));
   if ((*iac).cspl==NULL) {printf("ERR: alloc csp list mudr\n"); return -1;}

   GetCsp(fp_dat, (*iac).cspl, n_data);

   if (nbr_d!=NULL) *nbr_d = n_data;
   fclose(fp_dat);
   return 0;
}
//------------------------------------------------------------------------------
void GetCsp(FILE* fp, csp_t* cspl, int n_data)
{
   char line[CSP_MAX_LINE];
   int  i=0;
   int  nbr_read;
   while (fgets(line, sizeof(line), fp)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         if (i==0) { //first row is different...
            nbr_read = sscanf(line, "%lf %*s %*s %*s %*s %s", 
                  &((cspl[i]).x),
                  (cspl[i]).type);
            (cspl[i]).a = NAN;
            (cspl[i]).b = NAN;
            (cspl[i]).c = NAN;
            (cspl[i]).d = NAN;
         if (nbr_read != 2) printf("WAR: unknown structure in CSP file\n");
         } else {
         nbr_read = sscanf(line, "%lf %lf %lf %lf %lf %s",
                           &((cspl[i]).x), 
                           &((cspl[i]).a), 
                           &((cspl[i]).b), 
                           &((cspl[i]).c), 
                           &((cspl[i]).d), 
                           (cspl[i]).type);
         if (nbr_read != 6) printf("WAR: unknown structure in CSP file\n");
         }
         ++i;
      }
   }
   if (i!=n_data) printf("WAR: i=%d is unequal n_data=%d\n", i, n_data);
}
//------------------------------------------------------------------------------
int GetMudr(mudr_t* mdr, const char* z_str, int* nbr_i, int* nbr_d, xset_t* s) 
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return -1;}
   char path[PATH_LEN+PATH_EXTRA];
   sprintf(path, "%s/mudr", s->path_data);
   char file_name[PATH_LEN];
   sprintf(file_name, "%s/%03d_%s.txt", path, z, zToEl(z));
   FILE* fp_dat = fopen(file_name, "r");
   if (fp_dat==NULL) {printf("ERR: cannot open %s\n", file_name); exit(1);}

   int n_data = (s->len_mu_d)[z];

   (*mdr).z     = z;
   (*mdr).len_c = NBR_IA+1;
   (*mdr).len_d = n_data;
   FillMudr(fp_dat, &((*mdr).mudr), NBR_IA+1, n_data);

   if (nbr_i!=NULL) *nbr_i = NBR_IA+1;
   if (nbr_d!=NULL) *nbr_d = n_data;
   fclose(fp_dat);
   return 0;
}
//------------------------------------------------------------------------------
void FillMudr(FILE* fp_dat, double*** mdr, int nbr_c, int n_data)
{
   int i;
   *mdr = (double**) malloc(nbr_c * sizeof(double*));
   if (*mdr==NULL) {printf("ERR: alloc mdr\n"); exit(1);}
   for (i=0; i<=nbr_c-1; ++i) {
      (*mdr)[i] = (double*) malloc(n_data * sizeof(double));
      if ((*mdr)[i]==NULL) {printf("ERR: alloc mdr\n"); exit(1);}
   }

   i=0;
   char  line[4096];
   while (fgets(line, sizeof(line), fp_dat)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         sscanf(line, "%lf %lf %lf %lf %lf %lf %lf %lf",
               &((*mdr)[0][i]),&((*mdr)[1][i]),&((*mdr)[2][i]),&((*mdr)[3][i]),
               &((*mdr)[4][i]),&((*mdr)[5][i]),&((*mdr)[6][i]),&((*mdr)[7][i]));

         (*mdr)[0][i] *= 1000; //MeV to keV
         ++i;
      }
   }
}
//------------------------------------------------------------------------------
int GetF(double*** F_list, int* nbr_z, int* nbr_d, xset_t* s)
{
   FILE* fp_dat = s->fp_F;
   rewind(fp_dat);

   int n_data = s->len_F_d;
   int n_z    = s->len_F_Z; //col 0 is used for x-values in F and S lists
   int z;

   if (F_list!=NULL) {
      *F_list = (double**) malloc(n_z * sizeof(double*));
      if (*F_list==NULL) {printf("ERR: alloc F_list\n"); return 1;}
      for (z=0; z<=n_z-1; ++z) {
         (*F_list)[z] = (double*) malloc(n_data * sizeof(double));
         if ((*F_list)[z]==NULL) {printf("ERR: alloc F_list\n");return 1;}
      }
   }

   char  line[4096];
   char* token;
   int   i;
   int   row_cnt=0;
   while (fgets(line, sizeof(line), fp_dat)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         i=0;
         z=1;
         token = strtok (line," ");
         while (token != NULL) //go along one row (right)...
         {
            if (row_cnt >= n_data) printf("ERR: F row_cnt %d\n", row_cnt);
            if (z == n_z) break;
            if (i==0) {
               if (F_list!=NULL) (*F_list)[0][row_cnt] = atof(token);
            } else {
               if (i%2==1) {
                  if (F_list!=NULL) (*F_list)[z][row_cnt] = atof(token);
               } else {
                  ++z;
               }
            }
            token = strtok (NULL, " ");
            ++i;
         }
         ++row_cnt;
      }
   }

   if (nbr_z!=NULL) *nbr_z = n_z;
   if (nbr_d!=NULL) *nbr_d = n_data;
   return 0;
}
//------------------------------------------------------------------------------
int GetS(double*** S_list, int* nbr_z, int* nbr_d, xset_t* s)
{
   FILE* fp_dat = s->fp_S;
   rewind(fp_dat);

   int n_data = s->len_S_d;
   int n_z    = s->len_S_Z; //col 0 is used for x-values in F and S lists
   int z;

   if (S_list!=NULL) {
      *S_list = (double**) malloc(n_z * sizeof(double*));
      if (*S_list==NULL) {printf("ERR: alloc S_list\n"); return 1;}
      for (z=0; z<=n_z-1; ++z) {
         (*S_list)[z] = (double*) malloc(n_data * sizeof(double));
         if ((*S_list)[z]==NULL) {printf("ERR: alloc S_list\n");return 1;}
      }
   }
   char  line[4096];
   char* token;
   int   i;
   int   row_cnt=0;
   while (fgets(line, sizeof(line), fp_dat)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         i=0;
         z=1;
         token = strtok (line," ");
         while (token != NULL) //go along one row (right)...
         {
            if (row_cnt >= n_data) printf("ERR: S row_cnt %d\n", row_cnt);
            if (z == n_z) break;
            if (i==0) {
               if (S_list!=NULL) (*S_list)[0][row_cnt] = atof(token);
            } else {
               if (i%2==1) {
                  //do nothing
               } else {
                  if (S_list!=NULL) (*S_list)[z][row_cnt] = atof(token);
                  ++z;
               }
            }
            token = strtok (NULL, " ");
            ++i;
         }
         ++row_cnt;
      }
   }

   if (nbr_z!=NULL) *nbr_z = n_z;
   if (nbr_d!=NULL) *nbr_d = n_data;
   return 0;
}
//------------------------------------------------------------------------------
int GetI(double*** I_list, double*** dI_list, int* nbr_z, int* nbr_d, xset_t* s)
{
   FILE* fp_dat = s->fp_I;
   rewind(fp_dat);

   int n_data = 110;
   int n_z    = n_data+1; //col 0 is used for nbr_electrons in I_list
   int z;

   *I_list = (double**) malloc(n_z * sizeof(double*));
   if (*I_list==NULL) {printf("ERR: alloc I_list\n"); return 1;}
   for (z=0; z<=n_z-1; ++z) {
      (*I_list)[z] = (double*) malloc(n_data * sizeof(double));
      if ((*I_list)[z]==NULL) {printf("ERR: alloc I_list\n");return 1;}
   }
   if (dI_list!=NULL) {
      *dI_list = (double**) malloc(n_z * sizeof(double*));
      if (*dI_list==NULL) {printf("ERR: alloc dI_list\n"); return 1;}
      for (z=0; z<=n_z-1; ++z) {
         (*dI_list)[z] = (double*) malloc(n_data * sizeof(double));
         if ((*dI_list)[z]==NULL) {printf("ERR: alloc dI_list\n");return 1;}
      }
   }

   char  line[4096]; //the file has about 3400 character in a line
   char* token;
   char  err_token[128];
   int   c;
   int   row_cnt=0;
   while (fgets(line, sizeof(line), fp_dat)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         c=0; //column index
         z=1;
         token = strtok (line," ");
         while (token != NULL) //go along one row (right)...
         {
            if (row_cnt >= n_data) printf("ERR: I row_cnt %d\n", row_cnt);
            if (z == n_z) break;
            if (c==0) {
               (*I_list)[0][row_cnt] = atof(token);
            } else {
               if (c%2==1) { //ionization energy
                  (*I_list)[z][row_cnt] = atof(token) * 0.001; //eV to keV
               } else { //uncertainty
                  if (sscanf(token, "(%s)", err_token))
                     err_token[strlen(err_token)-1] = '\0'; //remove last ')'
                  if (dI_list != NULL) {
                     if (!strcmp(err_token, "?")) (*dI_list)[z][row_cnt] = NAN;
                     else (*dI_list)[z][row_cnt] = atof(err_token) *0.001;
                  }
                  ++z;
               }
            }
            token = strtok (NULL, " ");
            ++c;
         }
         ++row_cnt;
      }
   }

   if (nbr_z!=NULL) *nbr_z = n_z;
   if (nbr_d!=NULL) *nbr_d = n_data;
   return 0;
}
//------------------------------------------------------------------------------
void PrintI(double** I_list, double** dI_list, const char* z_str)
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return;}
   int r;
   if (I_list != NULL) {
      printf("\n--- IONIZATION LIST ---\n");
      printf("z=%3d: ", z);
      for (r=0; r<=z-1; ++r) {
         printf("%E ", I_list[z][r]);
      }
      printf("\n");
   }
   if (dI_list != NULL) {
      printf("\n--- IONIZATION UNCERTAINTY LIST ---\n");
      printf("z=%3d: ", z);
      for (r=0; r<=z-1; ++r) {
         printf("%E ", dI_list[z][r]);
      }
      printf("\n");
   }
}
//------------------------------------------------------------------------------
void PrintF(double** F_list, const char* z_str, xset_t* s)
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return;}
   int r; //row index
   int nbr_r = s->len_F_d;
   printf("\n--- ATOMIC FORM FACTOR F ---\n");
   printf("z=%3d:\n", z);
   printf("      X                F\n");
   for (r=0; r<=nbr_r-1; ++r) {
      printf("%E    %E\n", F_list[0][r], F_list[z][r]);
   }
}
//------------------------------------------------------------------------------
void PrintS(double** S_list, const char* z_str, xset_t* s)
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return;}
   int r; //row index
   int nbr_r = s->len_S_d;
   printf("\n--- INCOHERENT SCATTERING FUNCTION S ---\n");
   printf("z=%3d:\n", z);
   printf("      X                S\n");
   for (r=0; r<=nbr_r-1; ++r) {
      printf("%E    %E\n", S_list[0][r], S_list[z][r]);
   }
}
//------------------------------------------------------------------------------
double GiveRhoMix(rho_t* rho_list, const char* c_name, xset_t* s)
{
   int ic;
   int len = s->len_rhoM_comp;

   for (ic=0; ic<=len-1; ++ic) {
      if (!strcmp((rho_list[ic]).name, c_name)) {
         return (rho_list[ic]).rho;
      } 
   }
   printf("compound not found! -> check rhoComp.txt\n");
   return -1;
}
//------------------------------------------------------------------------------
double GiveRhoComp(rho_t* rho_list, const char* c_name, xset_t* s)
{
   int ic;
   int len = s->len_rhoC_comp;

   for (ic=0; ic<=len-1; ++ic) {
      if (!strcmp((rho_list[ic]).name, c_name)) {
         return (rho_list[ic]).rho;
      } 
   }
   printf("compound not found! -> check rhoComp.txt\n");
   return -1;
}
//------------------------------------------------------------------------------
void PrintRho(double* rho_list, double* rhoN_list, const char* z_str, xset_t* s)
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return;}
   if (rho_list!=NULL) {
      printf("\n--- DENSITY rho ---\n");
      printf("z=%3d:\n", z);
      if (z>0 && z<=s->len_rho_Z) {
         printf("rho = %f g/cm^3\n", rho_list[z]);
      } else {
         printf("z value %d out of range 1..%d!\n", z, s->len_rho_Z);
      }
   }
   if (rhoN_list!=NULL) {
      printf("\n--- NUMBER DENSITY rhoN ---\n");
      printf("z=%3d:\n", z);
      if (z>0 && z<=s->len_rho_Z) {
         printf("rhoN = %f * 10^21 #/cm^3\n", rhoN_list[z]);
      } else {
         printf("z value %d out of range 1..%d!\n", z, s->len_rho_Z);
      }
   }
}
//------------------------------------------------------------------------------
void PrintA(double* A_list, const char* z_str, xset_t* s)
{
   int z = ArgToZ(z_str);
   if (z==-1) {printf("WAR: unknown element %s\n", z_str); return;}
   if (A_list!=NULL) {
      printf("\n--- ATOMIC WEIGHT A ---\n");
      printf("z=%3d:\n", z);
      if (z>0 && z<=s->len_am_Z) {
         printf("A = %f \n", A_list[z]);
      } else {
         printf("z value %d out of range 1..%d!\n", z, s->len_am_Z);
      }
   }
}
//------------------------------------------------------------------------------
int GetA(double** A_list, int* nbr_z, xset_t* s)
{
   FILE* fp_dat = s->fp_am;
   rewind(fp_dat);

   int rows = s->len_am_Z;
   if (A_list!=NULL) {
      *A_list = (double*) malloc(rows * sizeof(double));
      if (*A_list==NULL) {printf("ERR: cannot alloc A_list\n"); return 1;}
   }

   int    z;
   double a;
   char   line[4096];
   while (fgets(line, sizeof(line), fp_dat)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         sscanf(line, "%d %*s %lf %*s %*s\n", &z, &a);
         (*A_list)[z]  = a;
      }
   }

   if (nbr_z!=NULL) *nbr_z = rows;
   return 0;
}
//------------------------------------------------------------------------------
int GetRhoComp(rho_t** rho_list, int* length, xset_t* s)
{
   FILE* fp_dat = s->fp_rhoC;
   rewind(fp_dat);

   int rows = s->len_rhoC_comp;
   if (rho_list!=NULL) {
      *rho_list = (rho_t*) malloc(rows * sizeof(rho_t));
      if (*rho_list==NULL) {printf("ERR: cannot alloc rho_list\n"); return 1;}
   }

   int    i_comp=0;
   double rho;
   char   name[256];
   char   line[4096];
   while (fgets(line, sizeof(line), fp_dat)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         sscanf(line, "%s  %lf\n", name, &rho);
         strcpy(((*rho_list)[i_comp]).name, name);
         ((*rho_list)[i_comp]).rho = rho;
         ++i_comp;
      }
   }

   if (length!=NULL) *length = rows;
   return 0;
}
//------------------------------------------------------------------------------
int GetRhoMix(rho_t** rho_list, int* length, xset_t* s)
{
   FILE* fp_dat = s->fp_rhoM;
   rewind(fp_dat);

   int rows = s->len_rhoM_comp;
   if (rho_list!=NULL) {
      *rho_list = (rho_t*) malloc(rows * sizeof(rho_t));
      if (*rho_list==NULL) {printf("ERR: cannot alloc rho_list\n"); return 1;}
   }

   int    i_comp=0;
   double rho;
   char   name[256];
   char   line[4096];
   while (fgets(line, sizeof(line), fp_dat)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         sscanf(line, "%s  %lf\n", name, &rho);
         strcpy(((*rho_list)[i_comp]).name, name);
         ((*rho_list)[i_comp]).rho = rho;
         ++i_comp;
      }
   }

   if (length!=NULL) *length = rows;
   return 0;
}
//------------------------------------------------------------------------------
int GetRho(double** rho_list, double** rhoN_list, int* nbr_z, xset_t* s)
{
   FILE* fp_dat = s->fp_rho;
   rewind(fp_dat);

   int rows = s->len_rho_Z;
   if (rho_list!=NULL) {
      *rho_list = (double*) malloc(rows * sizeof(double));
      if (*rho_list==NULL) {printf("ERR: cannot alloc rho_list\n"); return 1;}
   }
   if (rhoN_list!=NULL) {
      *rhoN_list = (double*) malloc(rows * sizeof(double));
      if (*rhoN_list==NULL) {printf("ERR: cannot alloc rhoN_list\n"); return 1;}
   }

   int    z;
   double rho, rhoN;
   char   line[4096];
   while (fgets(line, sizeof(line), fp_dat)) {//go to next row (down)...
      if (line[0]!='#') {//ignore comments
         sscanf(line, "%d %*s %*f %lf %lf\n", &z, &rho, &rhoN);
         if (rho_list!=NULL)  (*rho_list)[z]  = rho;
         if (rhoN_list!=NULL) (*rhoN_list)[z] = rhoN;
      }
   }

   if (nbr_z!=NULL) *nbr_z = rows;
   return 0;
}
//------------------------------------------------------------------------------
int ErrToken(char* token)
{
   int size = strlen(token);
   if (size >= 11) return 1;
   int i;
   for (i=0; i<=size-1; ++i) {
      if (token[i]=='0' || token[i]=='1' || token[i]=='2' || token[i]=='3' ||
          token[i]=='4' || token[i]=='5' || token[i]=='6' || token[i]=='7' ||
          token[i]=='8' || token[i]=='9' || token[i]=='E' || token[i]=='.' ||
          token[i]=='-' || token[i]=='+' || token[i]=='\n') {
         //good
      } else {
         printf("err with %c = %d at i=%d\n", token[i], token[i], i);
         return 1;
      }
   }
   return 0;
}
//------------------------------------------------------------------------------
void FreeMix(mix_t* mix)
{
   free(mix->z_list);
   free(mix->m_frac);
   mix->z_list = NULL;
   mix->m_frac = NULL;
}
//------------------------------------------------------------------------------
void FreeJTotal(acp_t* J)
{
   int is;
   int nbr_shells = J->nbr_shells;
   for (is=0; is<=nbr_shells-1; ++is) {
      free(((J->al)[is]).cspl);
      ((J->al)[is]).cspl = NULL;
   }
   free(J->al);
   J->al = NULL;
}
//------------------------------------------------------------------------------
void FreeJTotalMix(acp_t* J)
{
   FreeJTotal(J);
}
//------------------------------------------------------------------------------
void FreeJTotalComp(acp_t* J)
{
   FreeJTotal(J);
}
//------------------------------------------------------------------------------
void FreeMudrCsp(iac_t* iac)
{
   free((*iac).cspl);
   (*iac).cspl = NULL;
}
//------------------------------------------------------------------------------
void FreeMudrCspMix(iac_t* iac)
{
   FreeMudrCsp(iac);
}
//------------------------------------------------------------------------------
void FreeMudrCspComp(iac_t* iac)
{
   FreeMudrCsp(iac);
}
//------------------------------------------------------------------------------
void FreeFCsp(fs_t* f_fact)
{
   free((*f_fact).cspl);
   (*f_fact).cspl = NULL;
}
//------------------------------------------------------------------------------
void FreeSCsp(fs_t* s_fact)
{
   free((*s_fact).cspl);
   (*s_fact).cspl = NULL;
}
//------------------------------------------------------------------------------
void FreeJShells(cprof_t* cprof)
{
   int is;
   int nbr_s = cprof->nbr_shells;
   for (is=0; is<=nbr_s-1; ++is) {
      free(((cprof->sl)[is]).cspl);
      ((cprof->sl)[is]).cspl = NULL;
   }
   free(cprof->sl);
   cprof->sl = NULL;
}
//------------------------------------------------------------------------------
void FreeMudr(mudr_t* mdr)
{
   int nbr_interactions = (*mdr).len_c;

   int ia;
   for (ia=0; ia<=nbr_interactions-1; ++ia) {
      free(((*mdr).mudr)[ia]);
      ((*mdr).mudr)[ia] = NULL;
   }
   free((*mdr).mudr);
   (*mdr).mudr = NULL;
}
//------------------------------------------------------------------------------
void FreeJ(double**** J_list, int** ns, int*** ne, double*** be, xset_t* s)
{
   int nbr_z = s->len_J_Z;
   int z, si; //atomic number, shell index
   if (J_list!=NULL && ns!=NULL) {
      for (z=0; z<= nbr_z-1; ++z) {
         for (si=0; si<=(*ns)[z]; ++si) {
            free((*J_list)[z][si]);
            (*J_list)[z][si] = NULL;
         }
         free((*J_list)[z]);
         (*J_list)[z] = NULL;
      }
      free(*J_list);
      *J_list = NULL;
      free(*ns);
      *ns = NULL;
   } else {
      printf("ERR: free of Jsub_list requires ns!\n");
      return;
   }

   if (ns!=NULL) {
   }

   if (ne!=NULL) {
      for (z=0; z<= nbr_z-1; ++z) {
         free((*ne)[z]);
         (*ne)[z] = NULL;
      }
      free(*ne);
      *ne = NULL;
   }
   if (be!=NULL) {
      for (z=0; z<= nbr_z-1; ++z) {
         free((*be)[z]);
         (*be)[z] = NULL;
      }
      free(*be);
      *be = NULL;
   }
}
//------------------------------------------------------------------------------
void FreeI(double*** I_list, double*** dI_list, xset_t* s)
{
   int z=0;
   int nbr_z = s->len_I_Z;
   if (I_list!=NULL) {
      for (z=0; z<=nbr_z-1; ++z) {
         free((*I_list)[z]);
         (*I_list)[z] = NULL;
      }
      free(*I_list);
      *I_list = NULL;
   }
   if (dI_list!=NULL) {
      for (z=0; z<= nbr_z-1; ++z) {
         free((*dI_list)[z]);
         (*dI_list)[z] = NULL;
      }
      free(*dI_list);
      *dI_list = NULL;
   }
}
//------------------------------------------------------------------------------
void FreeF(double*** F_list, xset_t* s)
{
   int z;
   int nbr_z = s->len_F_Z;
   for (z=0; z<= nbr_z-1; ++z) {
      free((*F_list)[z]);
      (*F_list)[z] = NULL;
   }
   free(*F_list);
   *F_list = NULL;
}
//------------------------------------------------------------------------------
void FreeS(double*** S_list, xset_t* s)
{
   int z;
   int nbr_z = s->len_S_Z;
   for (z=0; z<= nbr_z-1; ++z) {
      free((*S_list)[z]);
      (*S_list)[z] = NULL;
   }
   free(*S_list);
   *S_list = NULL;
}
//------------------------------------------------------------------------------
void FreeRhoComp(rho_t** rho_list)
{
   free(*rho_list);
   *rho_list = NULL;
}
//------------------------------------------------------------------------------
void FreeRhoMix(rho_t** rho_list)
{
   free(*rho_list);
   *rho_list = NULL;
}
//------------------------------------------------------------------------------
void FreeRho(double** rho_list, double** rhoN_list)
{
   if (rho_list!=NULL) {
      free(*rho_list);
      *rho_list = NULL;
   }
   if (rhoN_list!=NULL) {
      free(*rhoN_list);
      *rhoN_list = NULL;
   }
}
//------------------------------------------------------------------------------
void FreeA(double** am_list)
{
   free(*am_list);
   *am_list = NULL;
}
//------------------------------------------------------------------------------
void FreeShellList(jshell_t** shell_list, int nbr_shells)
{
   int is;
   for (is=0; is <= nbr_shells-1; ++is) {
      free(((*shell_list)[is]).jl);
      ((*shell_list)[is]).jl = NULL;
   }
   free(*shell_list);
   *shell_list = NULL;
}
//------------------------------------------------------------------------------
void FreeCombShell(jshell_t** tot_s_list, int ns_tot)
{ 
   int is;
   for (is=0; is <= ns_tot-1; ++is) {
      free(((*tot_s_list)[is]).jl);
      ((*tot_s_list)[is]).jl = NULL;

   }
   free(*tot_s_list);
   *tot_s_list = NULL;
}
//------------------------------------------------------------------------------
const char* zToEl(int z)
{
    if (z==1)   return "H" ;  
    if (z==2)   return "He";   
    if (z==3)   return "Li";
    if (z==4)   return "Be";
    if (z==5)   return "B" ; 
    if (z==6)   return "C" ;
    if (z==7)   return "N" ;
    if (z==8)   return "O" ;
    if (z==9)   return "F" ;
    if (z==10)  return "Ne";
    if (z==11)  return "Na";
    if (z==12)  return "Mg";
    if (z==13)  return "Al";
    if (z==14)  return "Si";
    if (z==15)  return "P" ;
    if (z==16)  return "S" ;
    if (z==17)  return "Cl";
    if (z==18)  return "Ar";
    if (z==19)  return "K" ;
    if (z==20)  return "Ca";
    if (z==21)  return "Sc";
    if (z==22)  return "Ti";
    if (z==23)  return "V" ;
    if (z==24)  return "Cr";
    if (z==25)  return "Mn";
    if (z==26)  return "Fe";
    if (z==27)  return "Co";
    if (z==28)  return "Ni";
    if (z==29)  return "Cu";
    if (z==30)  return "Zn";
    if (z==31)  return "Ga";
    if (z==32)  return "Ge";
    if (z==33)  return "As";
    if (z==34)  return "Se";
    if (z==35)  return "Br";
    if (z==36)  return "Kr";
    if (z==37)  return "Rb";
    if (z==38)  return "Sr";
    if (z==39)  return "Y" ;
    if (z==40)  return "Zr";
    if (z==41)  return "Nb";
    if (z==42)  return "Mo";
    if (z==43)  return "Tc";
    if (z==44)  return "Ru";
    if (z==45)  return "Rh";
    if (z==46)  return "Pd";
    if (z==47)  return "Ag";
    if (z==48)  return "Cd";
    if (z==49)  return "In";
    if (z==50)  return "Sn";
    if (z==51)  return "Sb";
    if (z==52)  return "Te";
    if (z==53)  return "I" ; 
    if (z==54)  return "Xe";
    if (z==55)  return "Cs";
    if (z==56)  return "Ba";
    if (z==57)  return "La";
    if (z==58)  return "Ce";
    if (z==59)  return "Pr";
    if (z==60)  return "Nd";
    if (z==61)  return "Pm";
    if (z==62)  return "Sm";
    if (z==63)  return "Eu";
    if (z==64)  return "Gd";
    if (z==65)  return "Tb";
    if (z==66)  return "Dy";
    if (z==67)  return "Ho";
    if (z==68)  return "Er";
    if (z==69)  return "Tm";
    if (z==70)  return "Yb";
    if (z==71)  return "Lu";
    if (z==72)  return "Hf";
    if (z==73)  return "Ta";
    if (z==74)  return "W" ;
    if (z==75)  return "Re";
    if (z==76)  return "Os";
    if (z==77)  return "Ir";
    if (z==78)  return "Pt";
    if (z==79)  return "Au";
    if (z==80)  return "Hg";
    if (z==81)  return "Tl";
    if (z==82)  return "Pb";
    if (z==83)  return "Bi";
    if (z==84)  return "Po";
    if (z==85)  return "At";
    if (z==86)  return "Rn";
    if (z==87)  return "Fr";
    if (z==88)  return "Ra";
    if (z==89)  return "Ac";
    if (z==90)  return "Th";
    if (z==91)  return "Pa";
    if (z==92)  return "U" ;
    if (z==93)  return "Np";
    if (z==94)  return "Pu";
    if (z==95)  return "Am";
    if (z==96)  return "Cm";
    if (z==97)  return "Bk";
    if (z==98)  return "Cf";
    if (z==99)  return "Es";
    if (z==100) return "Fm";
    if (z==101) return "Md";
    if (z==102) return "No";
    if (z==103) return "Lr";
    if (z==104) return "Rf";
    if (z==105) return "Db";
    if (z==106) return "Sg";
    if (z==107) return "Bh";
    if (z==108) return "Hs";
    if (z==109) return "Mt";
    if (z==110) return "Ds";
    if (z==111) return "Rg";
    if (z==112) return "Cn";
    if (z==113) return "Nh";
    if (z==114) return "Fl";
    if (z==115) return "Mc";
    if (z==116) return "Lv";
    if (z==117) return "Ts";
    if (z==118) return "Og";

    return "Xx";
}
//------------------------------------------------------------------------------
int elToZ(const char* el)
{
    if (!strcmp(el, "H" ))  return 1;
    if (!strcmp(el, "He"))  return 2;
    if (!strcmp(el, "Li"))  return 3;
    if (!strcmp(el, "Be"))  return 4;
    if (!strcmp(el, "B" ))  return 5;
    if (!strcmp(el, "C" ))  return 6;
    if (!strcmp(el, "N" ))  return 7;
    if (!strcmp(el, "O" ))  return 8;
    if (!strcmp(el, "F" ))  return 9;
    if (!strcmp(el, "Ne"))  return 10;
    if (!strcmp(el, "Na"))  return 11;
    if (!strcmp(el, "Mg"))  return 12;
    if (!strcmp(el, "Al"))  return 13;
    if (!strcmp(el, "Si"))  return 14;
    if (!strcmp(el, "P" ))  return 15;
    if (!strcmp(el, "S" ))  return 16;
    if (!strcmp(el, "Cl"))  return 17;
    if (!strcmp(el, "Ar"))  return 18;
    if (!strcmp(el, "K" ))  return 19;
    if (!strcmp(el, "Ca"))  return 20;
    if (!strcmp(el, "Sc"))  return 21;
    if (!strcmp(el, "Ti"))  return 22;
    if (!strcmp(el, "V" ))  return 23;
    if (!strcmp(el, "Cr"))  return 24;
    if (!strcmp(el, "Mn"))  return 25;
    if (!strcmp(el, "Fe"))  return 26;
    if (!strcmp(el, "Co"))  return 27;
    if (!strcmp(el, "Ni"))  return 28;
    if (!strcmp(el, "Cu"))  return 29;
    if (!strcmp(el, "Zn"))  return 30;
    if (!strcmp(el, "Ga"))  return 31;
    if (!strcmp(el, "Ge"))  return 32;
    if (!strcmp(el, "As"))  return 33;
    if (!strcmp(el, "Se"))  return 34;
    if (!strcmp(el, "Br"))  return 35;
    if (!strcmp(el, "Kr"))  return 36;
    if (!strcmp(el, "Rb"))  return 37;
    if (!strcmp(el, "Sr"))  return 38;
    if (!strcmp(el, "Y" ))  return 39;
    if (!strcmp(el, "Zr"))  return 40;
    if (!strcmp(el, "Nb"))  return 41;
    if (!strcmp(el, "Mo"))  return 42;
    if (!strcmp(el, "Tc"))  return 43;
    if (!strcmp(el, "Ru"))  return 44;
    if (!strcmp(el, "Rh"))  return 45;
    if (!strcmp(el, "Pd"))  return 46;
    if (!strcmp(el, "Ag"))  return 47;
    if (!strcmp(el, "Cd"))  return 48;
    if (!strcmp(el, "In"))  return 49;
    if (!strcmp(el, "Sn"))  return 50;
    if (!strcmp(el, "Sb"))  return 51;
    if (!strcmp(el, "Te"))  return 52;
    if (!strcmp(el, "I" ))  return 53;
    if (!strcmp(el, "Xe"))  return 54;
    if (!strcmp(el, "Cs"))  return 55;
    if (!strcmp(el, "Ba"))  return 56;
    if (!strcmp(el, "La"))  return 57;
    if (!strcmp(el, "Ce"))  return 58;
    if (!strcmp(el, "Pr"))  return 59;
    if (!strcmp(el, "Nd"))  return 60;
    if (!strcmp(el, "Pm"))  return 61;
    if (!strcmp(el, "Sm"))  return 62;
    if (!strcmp(el, "Eu"))  return 63;
    if (!strcmp(el, "Gd"))  return 64;
    if (!strcmp(el, "Tb"))  return 65;
    if (!strcmp(el, "Dy"))  return 66;
    if (!strcmp(el, "Ho"))  return 67;
    if (!strcmp(el, "Er"))  return 68;
    if (!strcmp(el, "Tm"))  return 69;
    if (!strcmp(el, "Yb"))  return 70;
    if (!strcmp(el, "Lu"))  return 71;
    if (!strcmp(el, "Hf"))  return 72;
    if (!strcmp(el, "Ta"))  return 73;
    if (!strcmp(el, "W" ))  return 74;
    if (!strcmp(el, "Re"))  return 75;
    if (!strcmp(el, "Os"))  return 76;
    if (!strcmp(el, "Ir"))  return 77;
    if (!strcmp(el, "Pt"))  return 78;
    if (!strcmp(el, "Au"))  return 79;
    if (!strcmp(el, "Hg"))  return 80;
    if (!strcmp(el, "Tl"))  return 81;
    if (!strcmp(el, "Pb"))  return 82;
    if (!strcmp(el, "Bi"))  return 83;
    if (!strcmp(el, "Po"))  return 84;
    if (!strcmp(el, "At"))  return 85;
    if (!strcmp(el, "Rn"))  return 86;
    if (!strcmp(el, "Fr"))  return 87;
    if (!strcmp(el, "Ra"))  return 88;
    if (!strcmp(el, "Ac"))  return 89;
    if (!strcmp(el, "Th"))  return 90;
    if (!strcmp(el, "Pa"))  return 91;
    if (!strcmp(el, "U" ))  return 92;
    if (!strcmp(el, "Np"))  return 93;
    if (!strcmp(el, "Pu"))  return 94;
    if (!strcmp(el, "Am"))  return 95;
    if (!strcmp(el, "Cm"))  return 96;
    if (!strcmp(el, "Bk"))  return 97;
    if (!strcmp(el, "Cf"))  return 98;
    if (!strcmp(el, "Es"))  return 99;
    if (!strcmp(el, "Fm"))  return 100;
    if (!strcmp(el, "Md"))  return 101;
    if (!strcmp(el, "No"))  return 102;
    if (!strcmp(el, "Lr"))  return 103;
    if (!strcmp(el, "Unq")) return 104;
    if (!strcmp(el, "Rf"))  return 104;
    if (!strcmp(el, "Unp")) return 105;
    if (!strcmp(el, "Db"))  return 105;
    if (!strcmp(el, "Unh")) return 106;
    if (!strcmp(el, "Sg"))  return 106;
    if (!strcmp(el, "Uns")) return 107;
    if (!strcmp(el, "Bh"))  return 107;
    if (!strcmp(el, "Uno")) return 108;
    if (!strcmp(el, "Hs"))  return 108;
    if (!strcmp(el, "Une")) return 109;
    if (!strcmp(el, "Mt"))  return 109;
    if (!strcmp(el, "Uun")) return 110;
    if (!strcmp(el, "Ds"))  return 110;
    if (!strcmp(el, "Uuu")) return 111;
    if (!strcmp(el, "Rg"))  return 111;
    if (!strcmp(el, "Uub")) return 112;
    if (!strcmp(el, "Cn"))  return 112;
    if (!strcmp(el, "Uut")) return 113;
    if (!strcmp(el, "Nh"))  return 113;
    if (!strcmp(el, "Uuq")) return 114;
    if (!strcmp(el, "Fl"))  return 114;
    if (!strcmp(el, "Uup")) return 115;
    if (!strcmp(el, "Mc"))  return 115;
    if (!strcmp(el, "Uuh")) return 116;
    if (!strcmp(el, "Lv"))  return 116;
    if (!strcmp(el, "Uus")) return 117;
    if (!strcmp(el, "Ts"))  return 117;
    if (!strcmp(el, "Uuo")) return 118;
    if (!strcmp(el, "Og"))  return 118;
    return -1;
}
//------------------------------------------------------------------------------
int elLongToZ(const char* el)
{
    if (!strcmp(el, "Hydrogen"))      return 1;
    if (!strcmp(el, "Helium"))        return 2;
    if (!strcmp(el, "Lithium"))       return 3;
    if (!strcmp(el, "Beryllium"))     return 4;
    if (!strcmp(el, "Boron"))         return 5;
    if (!strcmp(el, "Carbon"))        return 6;
    if (!strcmp(el, "Nitrogen"))      return 7;
    if (!strcmp(el, "Oxygen"))        return 8;
    if (!strcmp(el, "Fluorine"))      return 9;
    if (!strcmp(el, "Neon"))          return 10;
    if (!strcmp(el, "Sodium"))        return 11;
    if (!strcmp(el, "Magnesium"))     return 12;
    if (!strcmp(el, "Aluminum"))      return 13;
    if (!strcmp(el, "Silicon"))       return 14;
    if (!strcmp(el, "Phosphorus"))    return 15;
    if (!strcmp(el, "Sulfur"))        return 16;
    if (!strcmp(el, "Chlorine"))      return 17;
    if (!strcmp(el, "Argon"))         return 18;
    if (!strcmp(el, "Potassium"))     return 19;
    if (!strcmp(el, "Calcium"))       return 20;
    if (!strcmp(el, "Scandium"))      return 21;
    if (!strcmp(el, "Titanium"))      return 22;
    if (!strcmp(el, "Vanadium"))      return 23;
    if (!strcmp(el, "Chromium"))      return 24;
    if (!strcmp(el, "Manganese"))     return 25;
    if (!strcmp(el, "Iron"))          return 26;
    if (!strcmp(el, "Cobalt"))        return 27;
    if (!strcmp(el, "Nickel"))        return 28;
    if (!strcmp(el, "Copper"))        return 29;
    if (!strcmp(el, "Zinc"))          return 30;
    if (!strcmp(el, "Gallium"))       return 31;
    if (!strcmp(el, "Germanium"))     return 32;
    if (!strcmp(el, "Arsenic"))       return 33;
    if (!strcmp(el, "Selenium"))      return 34;
    if (!strcmp(el, "Bromine"))       return 35;
    if (!strcmp(el, "Krypton"))       return 36;
    if (!strcmp(el, "Rubidium"))      return 37;
    if (!strcmp(el, "Strontium"))     return 38;
    if (!strcmp(el, "Yttrium"))       return 39;
    if (!strcmp(el, "Zirconium"))     return 40;
    if (!strcmp(el, "Niobium"))       return 41;
    if (!strcmp(el, "Molybdenum"))    return 42;
    if (!strcmp(el, "Technetium"))    return 43;
    if (!strcmp(el, "Ruthenium"))     return 44;
    if (!strcmp(el, "Rhodium"))       return 45;
    if (!strcmp(el, "Palladium"))     return 46;
    if (!strcmp(el, "Silver"))        return 47;
    if (!strcmp(el, "Cadmium"))       return 48;
    if (!strcmp(el, "Indium"))        return 49;
    if (!strcmp(el, "Tin"))           return 50;
    if (!strcmp(el, "Antimony"))      return 51;
    if (!strcmp(el, "Tellurium"))     return 52;
    if (!strcmp(el, "Iodine"))        return 53;
    if (!strcmp(el, "Xenon"))         return 54;
    if (!strcmp(el, "Cesium"))        return 55;
    if (!strcmp(el, "Barium"))        return 56;
    if (!strcmp(el, "Lanthanum"))     return 57;
    if (!strcmp(el, "Cerium"))        return 58;
    if (!strcmp(el, "Praseodymium"))  return 59;
    if (!strcmp(el, "Neodymium"))     return 60;
    if (!strcmp(el, "Promethium"))    return 61;
    if (!strcmp(el, "Samarium"))      return 62;
    if (!strcmp(el, "Europium"))      return 63;
    if (!strcmp(el, "Gadolinium"))    return 64;
    if (!strcmp(el, "Terbium"))       return 65;
    if (!strcmp(el, "Dysprosium"))    return 66;
    if (!strcmp(el, "Holmium"))       return 67;
    if (!strcmp(el, "Erbium"))        return 68;
    if (!strcmp(el, "Thulium"))       return 69;
    if (!strcmp(el, "Ytterbium"))     return 70;
    if (!strcmp(el, "Lutetium"))      return 71;
    if (!strcmp(el, "Hafnium"))       return 72;
    if (!strcmp(el, "Tantalum"))      return 73;
    if (!strcmp(el, "Tungsten"))      return 74;
    if (!strcmp(el, "Rhenium"))       return 75;
    if (!strcmp(el, "Osmium"))        return 76;
    if (!strcmp(el, "Iridium"))       return 77;
    if (!strcmp(el, "Platinum"))      return 78;
    if (!strcmp(el, "Gold"))          return 79;
    if (!strcmp(el, "Mercury"))       return 80;
    if (!strcmp(el, "Thallium"))      return 81;
    if (!strcmp(el, "Lead"))          return 82;
    if (!strcmp(el, "Bismuth"))       return 83;
    if (!strcmp(el, "Polonium"))      return 84;
    if (!strcmp(el, "Astatine"))      return 85;
    if (!strcmp(el, "Radon"))         return 86;
    if (!strcmp(el, "Francium"))      return 87;
    if (!strcmp(el, "Radium"))        return 88;
    if (!strcmp(el, "Actinium"))      return 89;
    if (!strcmp(el, "Thorium"))       return 90;
    if (!strcmp(el, "Protactinium"))  return 91;
    if (!strcmp(el, "Uranium"))       return 92;
    if (!strcmp(el, "Neptunium"))     return 93;
    if (!strcmp(el, "Plutonium"))     return 94;
    if (!strcmp(el, "Americium"))     return 95;
    if (!strcmp(el, "Curium"))        return 96;
    if (!strcmp(el, "Berkelium"))     return 97;
    if (!strcmp(el, "Californium"))   return 98;
    if (!strcmp(el, "Einsteinium"))   return 99;
    if (!strcmp(el, "Fermium"))       return 100;
    if (!strcmp(el, "Mendelevium"))   return 101;     
    if (!strcmp(el, "Nobelium"))      return 102;
    if (!strcmp(el, "Lawrencium"))    return 103;
    if (!strcmp(el, "Unnilquadium"))  return 104;
    if (!strcmp(el, "Rutherfordium")) return 104;
    if (!strcmp(el, "Unnilpentium"))  return 105;
    if (!strcmp(el, "Dubnium"))       return 105;
    if (!strcmp(el, "Unnilhexium"))   return 106;
    if (!strcmp(el, "Seaborgium"))    return 106;
    if (!strcmp(el, "Unnilseptium"))  return 107;
    if (!strcmp(el, "Bohrium"))       return 107;
    if (!strcmp(el, "Unniloctium"))   return 108;
    if (!strcmp(el, "Hassium"))       return 108;
    if (!strcmp(el, "Unnilennium"))   return 109;
    if (!strcmp(el, "Meitnerium"))    return 109;
    if (!strcmp(el, "Ununnilium"))    return 110;
    if (!strcmp(el, "Darmstadtium"))  return 110;
    if (!strcmp(el, "Unununium"))     return 111;
    if (!strcmp(el, "Roentgenium"))   return 111;
    if (!strcmp(el, "Ununbium"))      return 112;
    if (!strcmp(el, "Copernicium"))   return 112;
    if (!strcmp(el, "Ununtrium"))     return 113;
    if (!strcmp(el, "Nihonium"))      return 113;
    if (!strcmp(el, "Ununquadium"))   return 114;
    if (!strcmp(el, "Flerovium"))     return 114;
    if (!strcmp(el, "Ununpentium"))   return 115;
    if (!strcmp(el, "Moscovium"))     return 115;
    if (!strcmp(el, "Ununhexium"))    return 116;
    if (!strcmp(el, "Livermorium"))   return 116;
    if (!strcmp(el, "Ununseptium"))   return 117;
    if (!strcmp(el, "Tenness"))       return 117;
    if (!strcmp(el, "Ununoctium"))    return 118;
    if (!strcmp(el, "Oganesson"))     return 118;
    return -1;
}
//------------------------------------------------------------------------------
const char* iaToStr(int ia)
{
   if (ia==2) return "coh";
   if (ia==3) return "inc";
   if (ia==4) return "PE";
   if (ia==5) return "pairn";
   if (ia==6) return "paira";
   if (ia==7) return "all";
   if (ia==8) return "all-coh";
   return "not-found";
}
//------------------------------------------------------------------------------
int strToIa(const char* str)
{
   if (!strcmp(str, "coh"))     return 1;
   if (!strcmp(str, "inc"))     return 2;
   if (!strcmp(str, "PE"))      return 3;
   if (!strcmp(str, "pairn"))   return 4;
   if (!strcmp(str, "paira"))   return 5;
   if (!strcmp(str, "all"))     return 6;
   if (!strcmp(str, "all-coh")) return 7;
   return -1;
}
//------------------------------------------------------------------------------
void FreeXdata(xset_t* s)
{
   fclose(s->fp_I);
   fclose(s->fp_F);
   fclose(s->fp_S);
   fclose(s->fp_J);
   fclose(s->fp_am);
   fclose(s->fp_rho);
   fclose(s->fp_rhoC);
   fclose(s->fp_rhoM);
}
//------------------------------------------------------------------------------
void MakeSCspComp(fs_t* fs, xset_t* s, int n, ...)
{
   fs->z = -1;
   int nbr_el = n;// number of elements
   int ratio_list[nbr_el];
   int z_list[nbr_el];

   va_list valist;
   n*=2; //there are two variables (element_string, element_ratio) for each el.
   va_start(valist, n);
   ExtractCompArgs(valist, n, z_list, ratio_list);
   va_end(valist);

   double** S_list;
   GetS(&S_list, NULL, NULL, s);

   double* x;
   double* y;
   int xy_len;
   double ratio_list_db[nbr_el];
   int i; 
   for (i=0; i<=nbr_el-1; ++i) {
      ratio_list_db[i] = (double) ratio_list[i];
   }
   CombineS(&S_list, z_list, ratio_list_db, nbr_el, s, &x, &y, &xy_len);
   FreeS(&S_list, s);

   int len_csp=0; //len of CSP arrays
   MakeCSP(x, y, xy_len, &((*fs).cspl), &len_csp);
   (*fs).len  = len_csp;

   FreeXY(&x, &y);
}
//------------------------------------------------------------------------------
void MakeFCspMix(fs_t* fs, xset_t* s, mix_t* mix)
{
   fs->z = -1;
   int nbr_el = mix->nbr;// number of elements

   double* A_list;
   GetA(&A_list, NULL, s);
   double** F_list;
   GetF(&F_list, NULL, NULL, s);

   double* x;
   double* y;
   int xy_len;
   double ratio_list_db[nbr_el];
   int i, z_el; 
   for (i=0; i<=nbr_el-1; ++i) {
      z_el = (mix->z_list)[i];
      ratio_list_db[i] = (mix->m_frac)[i] / A_list[z_el];
   }
   CombineF(&F_list, (mix->z_list), ratio_list_db, nbr_el, s, &x, &y, &xy_len);
   FreeA(&A_list);
   FreeF(&F_list, s);

   int len_csp=0; //len of CSP arrays
   MakeCSP(x, y, xy_len, &((*fs).cspl), &len_csp);
   (*fs).len  = len_csp;

   FreeXY(&x, &y);
}
//------------------------------------------------------------------------------
void MakeSCspMix(fs_t* fs, xset_t* s, mix_t* mix)
{
   fs->z = -1;
   int nbr_el = mix->nbr;// number of elements

   double* A_list;
   GetA(&A_list, NULL, s);
   double** S_list;
   GetS(&S_list, NULL, NULL, s);

   double* x;
   double* y;
   int xy_len;
   double ratio_list_db[nbr_el];
   int i, z_el; 
   for (i=0; i<=nbr_el-1; ++i) {
      z_el = (mix->z_list)[i];
      ratio_list_db[i] = (mix->m_frac)[i] / A_list[z_el];
   }
   CombineS(&S_list, (mix->z_list), ratio_list_db, nbr_el, s, &x, &y, &xy_len);
   FreeA(&A_list);
   FreeS(&S_list, s);

   int len_csp=0; //len of CSP arrays
   MakeCSP(x, y, xy_len, &((*fs).cspl), &len_csp);
   (*fs).len  = len_csp;

   FreeXY(&x, &y);
}
//------------------------------------------------------------------------------
void MakeFCspComp(fs_t* fs, xset_t* s, int n, ...)
{
   fs->z = -1;
   int nbr_el = n;// number of elements
   int ratio_list[nbr_el];
   int z_list[nbr_el];

   va_list valist;
   n*=2; //there are two variables (element_string, element_ratio) for each el.
   va_start(valist, n);
   ExtractCompArgs(valist, n, z_list, ratio_list);
   va_end(valist);

   double** F_list;
   GetF(&F_list, NULL, NULL, s);

   double* x;
   double* y;
   int xy_len;
   double ratio_list_db[nbr_el];
   int i; 
   for (i=0; i<=nbr_el-1; ++i) {
      ratio_list_db[i] = (double) ratio_list[i];
   }
   CombineF(&F_list, z_list, ratio_list_db, nbr_el, s, &x, &y, &xy_len);
   FreeF(&F_list, s);

   int len_csp=0; //len of CSP arrays
   MakeCSP(x, y, xy_len, &((*fs).cspl), &len_csp);
   (*fs).len  = len_csp;

   FreeXY(&x, &y);
}
//----------------------------------------------------------------------------
void ExtractCompArgs(va_list valist, int n, int* z_list, int* ratio_list)
{
   int el_cnt=0;
   char el_str[4];

   int i;
   for (i=0; i<=n-1; ++i) {
      if (i%2==0) {
         strcpy(el_str, va_arg(valist, char*));
         z_list[el_cnt] = elToZ(el_str);
      } 
      else {
         ratio_list[el_cnt] = va_arg(valist, int);
         ++el_cnt;
      }
   }
}
//----------------------------------------------------------------------------
void MakeMudrCspComp(iac_t* iac, char* iac_str, xset_t* s, int n, ...)
{
   strcpy((*iac).type, iac_str);
   iac->z    = -1;

   int i;
   va_list valist;

   int nbr_el = n;// number of elements
   int el_cnt=0;
   mudr_t el_list[nbr_el];
   int ratio_list[nbr_el];
   int z_list[nbr_el];
   char el_str[4];

   double* A_list;
   GetA(&A_list, NULL, s);
   double m_tot = 0.0;

   n*=2; //there are two variables (element_string, element_ratio) for each el.
   va_start(valist, n);
   for (i=0; i<=n-1; ++i) {
      if (i%2==0) {
         strcpy(el_str, va_arg(valist, char*));
         z_list[el_cnt] = elToZ(el_str);
         GetMudr(&(el_list[el_cnt]), el_str, NULL, NULL, s);
      } 
      else {
         ratio_list[el_cnt] = va_arg(valist, int);
         ++el_cnt;
      }
   }
   va_end(valist);

   //make m_ratio
   double m_ratio_list[nbr_el];
   for (i=0; i<=nbr_el-1; ++i) {
      m_tot += ratio_list[i] * A_list[z_list[i]];
   }
   for (i=0; i<=nbr_el-1; ++i) {
      m_ratio_list[i] = ratio_list[i] * A_list[z_list[i]] / m_tot;
   }

   double* x;
   double* y;
   int xy_len;
   CombineMudr(el_list, m_ratio_list, nbr_el, iac_str, s, &x, &y, &xy_len);

   for (i=0; i<=nbr_el-1; ++i) {
      FreeMudr(&(el_list[i]));
   }

   int len_csp=0; //len of CSP arrays
   MakeCSP(x, y, xy_len, &((*iac).cspl), &len_csp);
   (*iac).len  = len_csp;

   
   FreeXY(&x, &y);
   FreeA(&A_list);
}
//----------------------------------------------------------------------------
void MakeMudrCspMix(iac_t* iac, char* iac_str, xset_t* s, mix_t* mix)
{
   strcpy((*iac).type, iac_str);
   iac->z    = -1;

   int i;
   int nbr_el = mix->nbr;// number of elements
   mudr_t el_list[nbr_el];

   for (i=0; i<=nbr_el-1; ++i) {
      GetMudr(&(el_list[i]), zToEl((mix->z_list)[i]), NULL, NULL, s);
   }

   double* x;
   double* y;
   int xy_len;
   CombineMudr(el_list, mix->m_frac, nbr_el, iac_str, s, &x, &y, &xy_len);

   for (i=0; i<=nbr_el-1; ++i) {
      FreeMudr(&(el_list[i]));
   }

   int len_csp=0; //len of CSP arrays
   MakeCSP(x, y, xy_len, &((*iac).cspl), &len_csp);
   (*iac).len  = len_csp;

   
   FreeXY(&x, &y);
}
//------------------------------------------------------------------------------
void CombineMudr(mudr_t* el_list, double* m_ratio_list, int nbr_el,
                 char* ia_str, xset_t* s, double** x_list, double** y_list, 
                 int* len)
{
   int i, r, d, j=0;
   //make X-list
   int edge = (!strcmp(ia_str, "PE")  ||  //mudr can have an edge
               !strcmp(ia_str, "all") ||
               !strcmp(ia_str, "all-coh"));
   int len_x=0;
   double x=0, x_last=-1;
   for (i=0; i<=nbr_el-1; ++i) len_x+=(el_list[i]).len_d; //maximal length
   double x_list_max[len_x]; //contains double x at edges (even for != PE)
   for (i=0; i<=nbr_el-1; ++i) {
      for (r=0; r<=(el_list[i]).len_d-1; ++r) {
         x = ((el_list[i]).mudr)[0][r];
         if (!(InList(x, x_list_max, j)) || (edge && x==x_last)) { 
            x_list_max[j] = x;
            ++j;
            if (j>=len_x) printf("ERR: CombMudr: j>=len_x: %d>=%d\n", j, len_x);
         }
         x_last = x;
      }
   }
   *len = j;
   qsort(x_list_max, j, sizeof(double), dcompare);
   (*x_list) = (double*) malloc(j * sizeof(double));
   if (*x_list == NULL) {printf("ERR: alloc x\n"); exit(1);}
   (*y_list) = (double*) malloc(j * sizeof(double));
   if (*y_list == NULL) {printf("ERR: alloc y\n"); exit(1);}
   for (i=0; i<=j-1; ++i) {
      (*x_list)[i] = x_list_max[i];
   }

   //make Y-list
   iac_t iacList[nbr_el];
   char z_str[8];
   for (i=0; i<=nbr_el-1; ++i) {
      sprintf(z_str, "%d", el_list[i].z);
      GetMudrCsp(&(iacList[i]), z_str, ia_str, NULL, s);
   }
   int ia = strToIa(ia_str);
   int e;
   double y_value, mudr;
   double result;
   x_last = -1;
   for (d=0; d<=j-1; ++d) {
      x = x_list_max[d];
      result = 0.0;
      for (e=0; e<=nbr_el-1; ++e) {
         if (ValueExist(x, x_last, &(el_list[e]), ia, &y_value)) {
            result += y_value * m_ratio_list[e];
         } else {
            mudr = CalcMudr(&(iacList[e]), x);
            result += mudr * m_ratio_list[e];
         }
      }
      (*y_list)[d] = result;
      x_last = x;
   }
   for (i=0; i<=nbr_el-1; ++i) {
      FreeMudrCsp(&(iacList[i]));
   }
}
//------------------------------------------------------------------------------
void CombineS(double*** S_list, int* z_list, double* ratio_list, int nbr_el, 
              xset_t* s, double** x, double** y, int* xy_len)
{
   int i, d;
   int nbr_d = s->len_S_d;
   double ratio_tot=0.0;
   for (i=0; i<=nbr_el-1; ++i) {
      ratio_tot += ratio_list[i];
   }

   double frac[nbr_el];
   for (i=0; i<=nbr_el-1; ++i) {
      frac[i] = ratio_list[i] / ratio_tot;
   }

   *x = (double*) malloc(nbr_d * sizeof(double));
   if (*x == NULL) {printf("ERR: alloc x\n"); exit(1);}
   *y = (double*) malloc(nbr_d * sizeof(double));
   if (*y == NULL) {printf("ERR: alloc y\n"); exit(1);}

   for (d=0; d<=nbr_d-1; ++d) {
      (*x)[d] = (*S_list)[0][d];
      (*y)[d] = 0.0;
      for (i=0; i<=nbr_el-1; ++i) {
         (*y)[d] += frac[i] * (*S_list)[z_list[i]][d];
      }
   }
   *xy_len = nbr_d;
}
//------------------------------------------------------------------------------
void CombineF(double*** F_list, int* z_list, double* ratio_list, int nbr_el, 
              xset_t* s, double** x, double** y, int* xy_len)
{
   int i, d;
   int nbr_d = s->len_F_d;
   double ratio_tot=0.0;
   for (i=0; i<=nbr_el-1; ++i) {
      ratio_tot += ratio_list[i];
   }

   double frac[nbr_el];
   for (i=0; i<=nbr_el-1; ++i) {
      frac[i] = ratio_list[i] / ratio_tot;
   }

   *x = (double*) malloc(nbr_d * sizeof(double));
   if (*x == NULL) {printf("ERR: alloc x\n"); exit(1);}
   *y = (double*) malloc(nbr_d * sizeof(double));
   if (*y == NULL) {printf("ERR: alloc y\n"); exit(1);}

   for (d=0; d<=nbr_d-1; ++d) {
      (*x)[d] = (*F_list)[0][d];
      (*y)[d] = 0.0;
      for (i=0; i<=nbr_el-1; ++i) {
         (*y)[d] += frac[i] * (*F_list)[z_list[i]][d];
      }
   }
   *xy_len = nbr_d;
}
//------------------------------------------------------------------------------
int approx_eq(double a, double b)
{
   if (a > b) {
      if (a-b < 0.00001) return 1;
   } else {
      if (a==b) return 1;
      if (b-a < 0.00001) return 1;
   }
   return 0;
}
//------------------------------------------------------------------------------
int InList(double x, double* x_list, int len)
{ 
   int i;
   for (i=0; i<=len-1; ++i) {
      if (x==x_list[i]) return 1;
      //if (approx_eq(x, x_list[i])) return 1;
   }
   return 0;
}
//------------------------------------------------------------------------------
int jscompare (const void * a, const void * b)
{
   jshell_t* shell_a = (jshell_t*) a;
   jshell_t* shell_b = (jshell_t*) b;
   double erg_a = shell_a->erg;
   double erg_b = shell_b->erg;
   if (erg_a > erg_b)
      return 1;
   else if (erg_a < erg_b)
      return -1;
   else
      return 0;  
}
//------------------------------------------------------------------------------
int dcompare (const void * a, const void * b)
{
  if (*(double*)a > *(double*)b)
    return 1;
  else if (*(double*)a < *(double*)b)
    return -1;
  else
    return 0;  
}
//------------------------------------------------------------------------------
int ValueExist(double x, double last_x, mudr_t* el, int ia, double* y)
{
   int d;
   int len = el->len_d;
   for (d=0; d<=len-1; ++d) {
      if (x == (el->mudr)[0][d]) {
         if (x==last_x) *y = (el->mudr)[ia][d+1];
         //if (approx_eq(x,last_x)) *y = (el->mudr)[ia][d+1];
         else *y = (el->mudr)[ia][d];
         return 1;
      }
   }
   return 0;
}
//------------------------------------------------------------------------------
void MakeCSP(double* x_in, double* y_in,int len_in,csp_t** csp_out,int* len_out)
{
   int nbr_seg = GetNbrSegments(x_in, y_in, len_in);
   int seglen_arr[nbr_seg];
   
   GetLenSegments(x_in, y_in, len_in, seglen_arr, nbr_seg);
   int max_len_seg=0;
   int i=0;
   for (i=0; i<=nbr_seg-1; ++i) {
      //printf("seglen_arr[%d] = %d\n", i, seglen_arr[i]);
      if (seglen_arr[i] > max_len_seg) max_len_seg = seglen_arr[i];
   }

   double** x_seg;
   double** y_seg;
   x_seg = (double**) malloc(nbr_seg*sizeof(double*));
   y_seg = (double**) malloc(nbr_seg*sizeof(double*));
   if (x_seg==NULL) {printf("ERR: alloc. x_seg\n"); exit(1);}
   if (y_seg==NULL) {printf("ERR: alloc. y_seg\n"); exit(1);}
   int s;
   for (s=0; s<=nbr_seg-1; ++s) { 
      x_seg[s] = (double*) malloc(max_len_seg*sizeof(double));
      if (x_seg[s]==NULL) {printf("ERR: alloc. x_seg\n"); exit(1);}
      y_seg[s] = (double*) malloc(max_len_seg*sizeof(double));
      if (y_seg[s]==NULL) {printf("ERR: alloc. y_seg\n"); exit(1);}
   }
   int* seg_type = (int*) malloc(nbr_seg*sizeof(int));
   if (seg_type==NULL) {printf("ERR: alloc seg_type\n"); exit(1);}
   FillSegments(x_in, y_in, len_in, x_seg, y_seg, seg_type, nbr_seg);

   csp_t* csp=(csp_t*) malloc(len_in * sizeof(csp_t));

   double a[max_len_seg]; double ae[1];
   double b[max_len_seg]; double be[1];  
   double c[max_len_seg]; double ce[1];
   double d[max_len_seg]; double de[1];
   double xe[2];
   int end;

   int len=0;
   if (seglen_arr[0]>=1) { //first line
      (csp[0]).x = x_in[0];
      (csp[0]).a=NAN; (csp[0]).b=NAN; (csp[0]).c=NAN; (csp[0]).d=NAN;
      strcpy((csp[0]).type, "-");
   }

   int k=1; //index for output arrays
   for(s=0; s<=nbr_seg-1; ++s) {
      len = seglen_arr[s];
      if (len<=1) {printf("WAR: csi with only one datapoint ?\n"); continue;}

      if (seg_type[s]==4) { //0 0 0 0
         Zero_lin(a, b, c, d, len);
         WriteOut(x_seg[s], len, "lin", a, b, c, d, csp, &k);
      }
      if (seg_type[s]==3) { //0 data 0
         //make linlin csi of all parts
         CubicSpline(x_seg[s], y_seg[s], len, a, b, c, d);
         //write linlin csi of begin part
         WriteOut(x_seg[s], 2, "lin", a, b, c, d, csp, &k);//write 1st el
         //save last element
         end = seglen_arr[s]-1;
         xe[1] = x_seg[s][end];
         ae[0] = a[end];
         be[0] = b[end];
         ce[0] = c[end];
         de[0] = d[end];
         //remove first and last 0
         RemoveFirstEl(x_seg[s], y_seg[s], len); --len;
         --len; //remove last element
         //make loglog csi of middle part
         CubicSplineLogLog(x_seg[s], y_seg[s], len, a,b,c,d);
         //write loglog csi of middle part
         WriteOut(x_seg[s], len, "log", a, b, c, d, csp, &k);
         //write linlin csi of end part
         WriteOut(xe, 2, "lin", ae, be, ce, de, csp, &k);//write only last el
      }
      if (seg_type[s]==2) { //data 0
         //make linlin csi of all parts
         CubicSpline(x_seg[s], y_seg[s], len, a, b, c, d);
         //save last element
         end = seglen_arr[s];
         xe[0] = x_seg[s][end];
         ae[0] = a[end];
         be[0] = b[end];
         ce[0] = c[end];
         de[0] = d[end];
         //remove last 0
         --len; //remove last element
         //make loglog csi of beg part
         CubicSplineLogLog(x_seg[s], y_seg[s], len, a,b,c,d);
         //write loglog csi of middle part
         WriteOut(x_seg[s], len, "log", a, b, c, d, csp, &k);
      }
      if (seg_type[s]==1) { //0 data
         //make linlin csi of all parts
         CubicSpline(x_seg[s], y_seg[s], len, a, b, c, d);
         //write linlin csi of begin part
         WriteOut(x_seg[s], 2, "lin", a, b, c, d, csp, &k);//wrt only 1st el
         //remove first 0
         RemoveFirstEl(x_seg[s], y_seg[s], len); --len;
         //make loglog csi of end part
         CubicSplineLogLog(x_seg[s], y_seg[s], len, a,b,c,d);
         //write loglog csi of end part
         WriteOut(x_seg[s], len, "log", a, b, c, d, csp, &k);
      }
      if (seg_type[s]==0) { //data (without zeros)
         CubicSplineLogLog(x_seg[s], y_seg[s], len, a,b,c,d);
         WriteOut(x_seg[s], len, "log", a, b, c, d, csp, &k);
      }
   }
   for (s=0; s<=nbr_seg-1; ++s) { 
      free(x_seg[s]);
      free(y_seg[s]);
   }
   free(x_seg);
   free(y_seg);
   free(seg_type);

   (*csp_out) = (csp_t*) malloc(k * sizeof(csp_t));
   for (i=0; i<=k-1; ++i) {
      (*csp_out)[i] = csp[i];
   }
   free(csp);
   *len_out = k;
}
//------------------------------------------------------------------------------
int GetNbrSegments(double* erg, double* data, int len)
{
   if (len==0) return 0;
   if (len==1) return 1;
   int cnt=1;
   int i;
   for (i=0; i<=len-2; ++i) {
      if ((erg[i]==erg[i+1]) && (data[i]!=data[i+1])) ++cnt;
      if ((data[i]==0 && data[i+1]!=0) || (data[i]!=0 && data[i+1]==0)) {
         if (i!=0) ++cnt;
      }
   }
   return cnt;
}
//------------------------------------------------------------------------------
void GetLenSegments(double* erg,double* data,int len,int* len_seg,int nbr_seg)
{
   int    i;
   int    d=0; //data index
   int    seg_cnt=0;
   for (i=0; i<=len-2; ++i) {
      ++d;
      if (seg_cnt >= nbr_seg) {
         printf("ERR: seg_cnt >= nbr_seg: %d >= %d\n", seg_cnt, nbr_seg);
         exit(1);
      }

      if ((erg[i]==erg[i+1]) && (data[i]!=data[i+1])) { //PE step
         len_seg[seg_cnt]  = d;
         ++seg_cnt;
         d=0;
      }
      if (data[i]==0 && data[i+1]!=0) { //0 -> !0 "step"
         if (i!=0) { //added
            len_seg[seg_cnt]  = d;
         //len_seg[seg_cnt]  = d+1; //fix for S_csp
            ++seg_cnt;
            d=1; //add space for last x,y pair for next segment
         //d=0; //fix S_csp
         }
      }
      if (data[i]!=0 && data[i+1]==0) { //!0 -> 0 "step"
         len_seg[seg_cnt]  = d+1; //add space for first x,y pair of next seg.
         ++seg_cnt;
         d=0;
      }
   }
   //write last segment
   len_seg[seg_cnt] = d+1;
}
//------------------------------------------------------------------------------
void FillSegments(double* erg,double* data, int len,
                  double** x_seg, double** y_seg, int* seg_type, int nbr_seg)
{
   int i;
   int d=0; //data index
   int seg_cnt=0;
   int prev_step=0;
   int yzero_start=0;
   int xzero_start=0;
   int yzero_end=0;
   //0 = no zero start, no zero end of segment
   //1 = zero start, no zero end of segment
   //2 = no zero start, zero end of segment
   //3 = zero start, zero end of segment
   //4 = zero start, zero end, everything zero segment

   for (i=0; i<=len-2; ++i) {
      if (seg_cnt >= nbr_seg) {
         printf("ERR: seg_cnt >= nbr_seg: %d >= %d\n", seg_cnt, nbr_seg);
         exit(1);
      }

      x_seg[seg_cnt][d] = erg[i];
      y_seg[seg_cnt][d] = data[i];
      if (d==0) {
         if (x_seg[seg_cnt][0]==0.0) xzero_start=1; 
         else xzero_start=0;
         if (y_seg[seg_cnt][0]==0.0) yzero_start=1; 
         else yzero_start=0;
      }
      ++d;

      if ((erg[i]==erg[i+1]) && (data[i]!=data[i+1])) { //PE step
         yzero_end=0;
         if (yzero_start || xzero_start) seg_type[seg_cnt] = 1; //added xzero...
         else seg_type[seg_cnt] = 0;
         ++seg_cnt;
         d=0;
         continue;
      }

      if (data[i]==0 && data[i+1]!=0 && !prev_step) { //0 -> !0 "step"
         if (i!=0) {//added
            yzero_end=1;
            if (yzero_start) seg_type[seg_cnt] = 4;
            else seg_type[seg_cnt] = -1;
            ++seg_cnt;
            --i; //add previous x,y pair
            prev_step=1;
            d=0;
            continue;
         }
      } else {
         prev_step=0;
      }
      if (data[i]!=0 && data[i+1]==0) { //!0 -> 0 "step"
         yzero_end=1;
         if (yzero_start) seg_type[seg_cnt] = 3;
         else seg_type[seg_cnt] = 2;
         x_seg[seg_cnt][d] = erg[i+1];
         y_seg[seg_cnt][d] = data[i+1];
         ++seg_cnt;
         d=0;
         continue;
      }
   }
   //write last segment
   x_seg[seg_cnt][d] = erg[i];
   y_seg[seg_cnt][d] = data[i];
   if (y_seg[seg_cnt][d]==0.0) yzero_end=1;
   else yzero_end=0;
   if (yzero_start) {
      if (yzero_end) {
         if (y_seg[seg_cnt][1]==0.0) seg_type[seg_cnt]=4; 
         else seg_type[seg_cnt]=3;
      }
      else seg_type[seg_cnt] = 1;
   }
   else {
      if (yzero_end) seg_type[seg_cnt] = 2;
      else {
        if (xzero_start) seg_type[seg_cnt] = 1; //added
        else seg_type[seg_cnt] = 0;
      }
   }
}
//------------------------------------------------------------------------------
void Zero_lin(double* a, double* b, double* c, double* d, int n)
{
   int i;
   --n;
   for (i=0; i<=n-1; ++i) {
      a[i]=0.0;
      b[i]=0.0;
      c[i]=0.0;
      d[i]=0.0;
   }
}
//------------------------------------------------------------------------------
void WriteOut(double* x, int length, const char* type, double* a, double* b,
              double* c, double* d, csp_t* csp, int* k)
{
   int i;
   int j = *k;

   for (i=1; i<=length-1; ++i) {
      (csp[j]).x = x[i];
      (csp[j]).a = a[i-1]; 
      (csp[j]).b = b[i-1];
      (csp[j]).c = c[i-1];
      (csp[j]).d = d[i-1];
      strcpy((csp[j]).type, type);
      ++j;
   }
   *k = j;
}
//------------------------------------------------------------------------------
void RemoveFirstEl(double* x, double* y, int len)
{
   int i;
   for (i=0; i<=len-2; ++i) {
      x[i] = x[i+1];
      y[i] = y[i+1];
   }
}
//------------------------------------------------------------------------------
void CubicSplineLogLog(double* x_orig, double* y_orig, int n, double* a,
                       double* b, double* c, double* d)
{
   int i;
   double x[n]; //contains log values   
   double y[n]; //contains log values

   //this part is not used if a Zero segmentaition is used as in
   //MakeMaterialCSP_mudivrho.c (for y)
   //x is not zero
   for (i=0; i<=n-1; ++i) {
      if (x_orig[i] == 0.0) x[i] = -30;
      else x[i] = log(x_orig[i]);
      if (y_orig[i] == 0.0) y[i] = -30;
      else y[i] = log(y_orig[i]);
   }

   --n;
   double h[n];
   double alpha[n];
   for (i=0; i<=n-1; ++i) h[i] = x[i+1] - x[i];
   for (i=1; i<=n-1; ++i) alpha[i] = 3.0/h[i] * (y[i+1]-y[i]) -
                                     3.0/h[i-1] * (y[i]-y[i-1]);
   double l[n];
   double mu[n];
   double z[n];
   l[0]=1, mu[0]=0, z[0]=0;
   for (i=1; i<=n-1; ++i) {
      l[i]  = 2.0 * (x[i+1] - x[i-1]) - h[i-1]*mu[i-1];
      mu[i] = h[i]/l[i];
      z[i]  = (alpha[i] - h[i-1] * z[i-1]) / l[i];
   }

   a[n-1] = y[n-1];
   c[n-1] = z[n-1];
   b[n-1] = (y[n] - y[n-1])/h[n-1] - h[n-1]*(2*c[n-1])/3.0;
   d[n-1] = (-c[n-1])/(3.0*h[n-1]);
   for (i=n-2; i>=0; --i) {
      a[i] = y[i];
      c[i] = z[i] - mu[i]*c[i+1];
      b[i] = (y[i+1] - y[i])/h[i] - h[i]*(c[i+1] + 2*c[i])/3.0;
      d[i] = (c[i+1] - c[i])/(3.0*h[i]);
   }
}
//------------------------------------------------------------------------------
void CubicSpline(double* x, double* y, int n, double* a, double* b, 
                 double* c, double* d)
{
   --n;
   int i;
   double h[n];
   double alpha[n];
   for (i=0; i<=n-1; ++i) h[i] = x[i+1] - x[i];
   for (i=1; i<=n-1; ++i) alpha[i] = 3.0/h[i] * (y[i+1]-y[i]) -
                                     3.0/h[i-1] * (y[i]-y[i-1]);
   double l[n];
   double mu[n];
   double z[n];
   l[0]=1, mu[0]=0, z[0]=0;
   for (i=1; i<=n-1; ++i) {
      l[i]  = 2.0 * (x[i+1] - x[i-1]) - h[i-1]*mu[i-1];
      mu[i] = h[i]/l[i];
      z[i]  = (alpha[i] - h[i-1] * z[i-1]) / l[i];
   }

   a[n-1] = y[n-1];
   c[n-1] = z[n-1];
   b[n-1] = (y[n] - y[n-1])/h[n-1] - h[n-1]*(2*c[n-1])/3.0;
   d[n-1] = (-c[n-1])/(3.0*h[n-1]);
   for (i=n-2; i>=0; --i) {
      a[i] = y[i];
      c[i] = z[i] - mu[i]*c[i+1];
      b[i] = (y[i+1] - y[i])/h[i] - h[i]*(c[i+1] + 2*c[i])/3.0;
      d[i] = (c[i+1] - c[i])/(3.0*h[i]);
   }
}
//------------------------------------------------------------------------------
void FreeXY(double** x, double** y)
{
   free(*x);
   *x = NULL;
   free(*y);
   *y = NULL;
}
//------------------------------------------------------------------------------
double CalcQ(double E0, double theta, double E)
{
   double alpha_inv = 137.035999139;
   double th = theta/180.0 * M_PI;
   double Q = -alpha_inv * (E0 - E - E0*E*(1-cos(th))/ME) / 
      (sqrt(E0*E0 + E*E - 2*E0*E*cos(th)));
   if (Q<0) return -Q;
   else return Q;
}
//------------------------------------------------------------------------------
int ArgToZ(const char* z_str)
{
   int len, i;
   int z = elToZ(z_str);
   if (z==-1) {
      len = strlen(z_str);
      for (i=0; i<=len-1; ++i) {
         if (!isdigit(z_str[i])) return -1;
      }
      z=atoi(z_str);
      if (z>=1 && z<=118) return z;
      else return -1;
   }
   return z;
}
//------------------------------------------------------------------------------
double logScale(int i, double a, double b, double nbr)
{
   return exp(log(a) + i*(log(b)-log(a))/nbr);
}
//------------------------------------------------------------------------------
double linScale(int i, double a, double b, double nbr)
{
   return a + i*(b-a)/nbr;
}
//------------------------------------------------------------------------------
void FreeFCspMix(fs_t* F)
{
   FreeFCsp(F);
}
//------------------------------------------------------------------------------
void FreeSCspMix(fs_t* S)
{
   FreeSCsp(S);
}
//------------------------------------------------------------------------------
void FreeFCspComp(fs_t* F)
{
   FreeFCsp(F);
}
//------------------------------------------------------------------------------
void FreeSCspComp(fs_t* S)
{
   FreeSCsp(S);
}
//------------------------------------------------------------------------------
