#ifndef XDATA_H
#define XDATA_H

#define CFG_STR_LEN  256
#define PATH_LEN     256
#define PATH_EXTRA    16
#define MU_Z_MAX     100
#define NBR_IA       7     /*number of interactions: coh, inc, PE...*/
#define NBR_CSP      4     /*number of cubic spline coefficients: a, b, c, d*/
#define CSP_MAX_LINE 1024  /*maximal line width in CSP files*/
#define ME           510.9989461 /*rest mass of electron in keV*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>

typedef struct {
   char  path_data[PATH_LEN];
   FILE* fp_I;
   int   len_I_Z;
   int   len_I_d;
   FILE* fp_F;
   int   len_F_Z;
   int   len_F_d;
   int   len_Fcsp_d;
   FILE* fp_S;
   int   len_S_Z;
   int   len_S_d;
   int   len_Scsp_d;
   FILE* fp_J;
   int   len_J_Z;
   int   len_J_d;
   int   len_Jcsp_d;
   FILE* fp_rho;
   int   len_rho_Z;
   int   len_rho_d;
   FILE* fp_rhoC;
   int   len_rhoC_comp;
   int   len_rhoC_d;
   FILE* fp_rhoM;
   int   len_rhoM_comp;
   int   len_rhoM_d;
   FILE* fp_am;
   int   len_am_Z;
   int   len_am_d;
   int   len_mu_Z;
   int   len_mu_ia;
   int   len_mu_d[MU_Z_MAX+1];
   int   len_mucsp_Z;
   int   len_mucsp_ia;
   int   len_mucsp_d[MU_Z_MAX+1];
} xset_t;

typedef struct {
   char   name[256];
   double rho;
} rho_t;

typedef struct {
   double x;
   double a;
   double b;
   double c;
   double d;
   char   type[4];
} csp_t;

typedef struct {
   int      z;
   int      len_c;
   int      len_d;
   double** mudr;
} mudr_t;

typedef struct {
   int    z;
   int    len;
   char   type[16];
   csp_t* cspl;
} iac_t;

typedef struct {
   int     len;
   int     nbr_el;
   double  erg;
   double* jl;  /*list of J values*/
} jshell_t;

typedef struct {
   int    len;
   int    nbr_el;
   double erg;
   csp_t* cspl;
} shell_t;

typedef struct {
   int    len;
   double erg;
   csp_t* cspl;
} atomic_t;

typedef struct {
   int      z;
   int      nbr_shells;
   shell_t* sl;          /*shell list*/
} cprof_t; //to do: name it scp /*shell Compton profile*/

typedef struct {
   int       z;
   int       nbr_shells;
   atomic_t* al;          /*atomic J list*/
} acp_t;                  /*atomic Compton profile*/

typedef struct {
   int    z;
   int    len;
   csp_t* cspl;
} fs_t;

typedef struct {
   int     nbr;
   char    name[256];
   int*    z_list;
   double* m_frac;
} mix_t;


int  InitXdata(xset_t* s, const char* path);
void FreeXdata(xset_t* s);

int  GetI(double*** I_list, double*** dI_list, int* nbr_z,int* nbr_d,xset_t* s);
void FreeI(double*** I_list, double*** dI_list, xset_t* s);
void PrintI(double** I_list, double** dI_list, const char* z_str);

int  GetJ(double**** J_list, int** ns, int*** ne, double*** be,
          int* nbr_z, int* nbr_d, xset_t* s);
void FreeJ(double**** J_list, int** ns, int*** ne, double*** be, xset_t* s);
void FillNumberOfShellList(int** ns);
void PrintJ(double*** J_list, int* ns, int** ne,double** be, const char* z_str,
            xset_t* s);
int  CheckJ(double*** Jsub, int* ns, int** ne, xset_t* s);

int  GetJShells(cprof_t* cprof, const char* z_str, int* nbr_s, int* nbr_d,
               xset_t* s);
void FreeJShells(cprof_t* cprof);
int  FillJShell(shell_t* shell, const char* z_str, int shell_nbr, int*** ne,
               double*** be, int* nbr_d, xset_t* s);
double CalcJShell(cprof_t* cprof, int shell, double E0, double theta, double E);

void MakeJTotal(acp_t* J, const char* z_str, xset_t* s);
void FreeJTotal(acp_t* J);
void MakeJTotalComp(acp_t* J, xset_t* s, int n, ...);
void FreeJTotalComp(acp_t* J);
void MakeJTotalMix(acp_t* J, xset_t* s, mix_t* mix);
void FreeJTotalMix(acp_t* J);
void CalcCumulativeJ(jshell_t* shell_list, int nbr_shells);
void MakeCombShell(jshell_t** shell_lists, int* nbr_shells, double* ratio_list, 
                   int nbr_el, jshell_t** tot_s_list, int* total_nbr_shells);
void FreeCombShell(jshell_t** tot_s_list, int ns_tot);
void MakeShellList(double*** J_list, int* ns, int** ne, double** be, int z, 
                   xset_t* s, jshell_t** shell_list, int* nbr_shells);
void FreeShellList(jshell_t** shell_lists, int nbr_shells);
double CalcJTotal(acp_t* J, double E0, double theta, double E);

int  GetF(double*** F_list, int* nbr_z, int* nbr_d, xset_t* s);
void FreeF(double*** F_list, xset_t* s);
int  GetFCsp(fs_t* f, const char* z_str, int* nbr_d, xset_t* s);
void FreeFCsp(fs_t* f_fact);
void MakeFCspComp(fs_t* fs, xset_t* s, int n, ...);
void FreeFCspComp(fs_t* F);
void MakeFCspMix(fs_t* fs, xset_t* s, mix_t* mix);
void FreeFCspMix(fs_t* F);
void CombineF(double*** F_list, int* z_list, double* ratio_list, int nbr_el, 
              xset_t* s, double** x, double** y, int* xy_len);
void PrintF(double** F_list, const char* z_str, xset_t* s);
double CalcF(fs_t* f_fact, double erg, double theta);

int  GetS(double*** S_list, int* nbr_z, int* nbr_d, xset_t* s);
void FreeS(double*** S_list, xset_t* s);
void MakeSCspComp(fs_t* fs, xset_t* s, int n, ...);
void FreeSCspComp(fs_t* S);
void MakeSCspMix(fs_t* fs, xset_t* s, mix_t* mix);
void FreeSCspMix(fs_t* S);
void CombineS(double*** S_list, int* z_list, double* ratio_list, int nbr_el, 
              xset_t* s, double** x, double** y, int* xy_len);
void PrintS(double** S_list, const char* z_str, xset_t* s);
int  GetSCsp(fs_t* s_fact, const char* z_str, int* nbr_d, xset_t* s);
void FreeSCsp(fs_t* s_fact);
double CalcS(fs_t* s_fact, double erg, double theta);

int  GetRho(double** rho_list, double** rhoN_list, int* nbr_z, xset_t* s);
void FreeRho(double** rho_list, double** rhoN_list);
int  GetRhoComp(rho_t** rho_list, int* length, xset_t* s);
void FreeRhoComp(rho_t** rho_list);
int  GetRhoMix(rho_t** rho_list, int* length, xset_t* s);
void FreeRhoMix(rho_t** rho_list);
double GiveRhoComp(rho_t* rho_list, const char* c_name, xset_t* s);
double GiveRhoMix(rho_t* rho_list, const char* c_name, xset_t* s);
void PrintRho(double* rho_list, double* rhoN_list, const char* z_str,xset_t* s);

int  GetA(double** A_list, int* nbr_z, xset_t* s);
void FreeA(double** A_list);
void PrintA(double* A_list, const char* z_str, xset_t* s);

int  GetMudr(mudr_t* mdr, const char* z_str, int* nbr_i, int* nbr_d, xset_t* s);
void FreeMudr(mudr_t* mdr);
void FillMudr(FILE* fp_dat, double*** mrd, int nbr_c, int n_data);
void PrintMudr(mudr_t* mdr, double erg_a, double erg_b);

int  GetMudrCsp(iac_t* iac, const char* z_str, char* ia_str, int* nbr_d,
                xset_t* s);
void FreeMudrCsp(iac_t* iac);
void MakeMudrCspComp(iac_t* iac, char* iac_str, xset_t* s, int n, ...);
void FreeMudrCspComp(iac_t* iac);
void MakeMudrCspMix(iac_t* iac, char* iac_str, xset_t* s, mix_t* mix);
void FreeMudrCspMix(iac_t* iac);
void PrintMudrCsp(iac_t* iac);
double CalcMudr(iac_t* iac, double erg);
void CombineMudr(mudr_t* el_list, double* m_ratio_list, int n, char* ia_str,
                 xset_t* s, double** x_list, double** y_list, int* len);

int  GetMix(const char* name, mix_t* mix, int* nbr, xset_t* s);
void FreeMix(mix_t* mix);
int  GetNbrEl(FILE* fp, const char* name_search);
int  GetMixEl(FILE* fp, const char* name_search, mix_t* mix);
void GetCsp(FILE* fp, csp_t* cspl, int n_data);
double CalcCSI(csp_t* cspl, double x, int length);
int  EOL(char* token);
int  ErrToken(char* token);
int  GetTableSize(FILE* fp_dat, int* rows, int* cols, int size);
int  elToZ(const char* el);
int  elLongToZ(const char* el);
const char* zToEl(int z);
const char* iaToStr(int ia);
int  strToIa(const char* str);

int  InList(double x, double* x_list, int len);
int  dcompare (const void * a, const void * b);
int  jscompare (const void * a, const void * b);
int  ValueExist(double x, double last_x, mudr_t* el, int ia, double* y);
void MakeCSP(double* x_in, double* y_in, int len_in, csp_t** csp, int* len_out);
int  GetNbrSegments(double* erg, double* data, int len);
void GetLenSegments(double* erg,double* data,int len,int* len_seg,int nbr_seg);
void FillSegments(double* erg,double* data, int len,
                  double** x_seg, double** y_seg, int* seg_type, int nbr_seg);
void Zero_lin(double* a, double* b, double* c, double* d, int n);
void RemoveFirstEl(double* x, double* y, int len);
void CubicSpline(double* x, double* y, int n, double* a, double* b, 
                 double* c, double* d);
void CubicSplineLogLog(double* x_orig, double* y_orig, int n, double* a,
                       double* b, double* c, double* d);
void WriteOut(double* x, int length, const char* type, double* a, double* b,
              double* c, double* d, csp_t* csp, int* k);
void FreeXY(double** x, double** y);
void ExtractCompArgs(va_list valist, int n, int* z_list, int* ratio_list);
double CalcQ(double E0, double theta, double E);
int  ArgToZ(const char* z_str);
double logScale(int i, double a, double b, double nbr);
double linScale(int i, double a, double b, double nbr);
#endif
