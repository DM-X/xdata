#include <stdio.h>
#include <stdlib.h>
#include "../../xdata.h"

int main()
{
   //initialization reads the lengths of all lists and checks if all data can
   //be found
   xset_t s;
   if (InitXdata(&s, "../..")) {
      printf("ERR: initialization failed! Exit...\n");
      return 1;
   }
   printf("used path: %s\n", s.path_data);
   //---------------------------------------------------------------------------
   
   //using the rho_list 
   rho_t* rho_list;
   GetRhoMix(&rho_list, NULL, &s);
   printf("soft tissue density = %f\n", 
           GiveRhoMix(rho_list, "soft_tissue", &s));
   FreeRhoMix(&rho_list);
   //---------------------------------------------------------------------------

   //using the A_list
   // -> not defined for a mixturecompound
   //---------------------------------------------------------------------------
   
   //using the ionization list in combination with the uncertainty
   // -> not defined for a mixture
   //---------------------------------------------------------------------------
   //
   mix_t mix_st; //mixture variable for soft tissue
   GetMix("soft_tissue", &mix_st, NULL, &s);
   
   //using the F cubic spline interpolation for a mixture
   printf("\nF CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_F_st = fopen("test_F_st.dat", "w");
   if (fp_F_st==NULL) {printf("ERR: opening test_F_st.dat\n"); exit(1);}
   double ergF   = 60;
   double thetaF = 90;
   fs_t F_st;
   MakeFCspMix(&F_st, &s, &mix_st); 
   int iF;
   fprintf(fp_F_st, "E [keV]  theta [deg]  F []\n");
   for (iF=0; iF<=100; ++iF) {
      ergF = logScale(iF, 0.01, 200, 100);
      fprintf(fp_F_st, "%E %E %E\n", 
              ergF, thetaF, CalcF(&F_st, ergF, thetaF));
   }
   FreeFCspMix(&F_st);
   fclose(fp_F_st);
   printf("data written in 'test_F_st.dat'\n");
   //---------------------------------------------------------------------------
   
   //using the S cubic spline interpolation for a compound
   printf("\nS CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_S_st = fopen("test_S_st.dat", "w");
   if (fp_S_st==NULL) {printf("ERR: opening test_S_st.dat\n"); exit(1);}
   double ergS   = 60;
   double thetaS = 90;
   fs_t S_st;
   MakeSCspMix(&S_st, &s, &mix_st); 
   int iS;
   fprintf(fp_S_st, "E [keV]  theta [deg]  S []\n");
   for (iS=0; iS<=100; ++iS) {
      ergS = logScale(iS, 0.01, 200, 100);
      fprintf(fp_S_st, "%E %E  %E\n", 
              ergS, thetaS, CalcS(&S_st, ergS, thetaS));
   }
   FreeSCspMix(&S_st);
   fclose(fp_S_st);
   printf("data written in 'test_S_st.dat'\n");
   //---------------------------------------------------------------------------
   
   //using the J cubic spline interpolation -> total compton profiles
   printf("\nJ_TOTAL CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_Jtot_st = fopen("test_Jtotal_st.dat", "w");
   if (fp_Jtot_st==NULL) {printf("ERR: open test_Jtotal_st.dat\n");exit(1);}
   acp_t Jtot_st;
   MakeJTotalMix(&Jtot_st, &s, &mix_st);
   double EJ0   = 60;
   double EJ    = 50;
   double thJ   = 91.02;

   fprintf(fp_Jtot_st, "#E [keV]      Q []         J_total []\n");
   int ij;
   for (ij=0; ij<=5000; ++ij) {
      EJ = linScale(ij, 40, 65, 5000);
      fprintf(fp_Jtot_st,"%E  %E  %E\n", EJ, CalcQ(EJ0, thJ, EJ),
              CalcJTotal(&Jtot_st, EJ0, thJ, EJ));
   }
   FreeJTotalMix(&Jtot_st);
   fclose(fp_Jtot_st);
   printf("data written in 'test_Jtotal_st.dat'\n");
   //---------------------------------------------------------------------------

   //using the mu/rho_csp_list for a mixture
   printf("\nmu/rho MASS ATTENUATION COEFFICIENT CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_mudr_st = fopen("test_mudr_st.dat", "w");
   if (fp_mudr_st==NULL) {printf("ERR: opening test_mudr_Si.dat\n");exit(1);}

   iac_t iac_st_coh, iac_st_inc, iac_st_pe;
   iac_t iac_st_pn, iac_st_pa, iac_st_all;
   MakeMudrCspMix(&iac_st_coh, "coh",   &s, &mix_st);
   MakeMudrCspMix(&iac_st_inc, "inc",   &s, &mix_st);
   MakeMudrCspMix(&iac_st_pe,  "PE",    &s, &mix_st);
   MakeMudrCspMix(&iac_st_pn,  "pairn", &s, &mix_st);
   MakeMudrCspMix(&iac_st_pa,  "paira", &s, &mix_st);
   MakeMudrCspMix(&iac_st_all, "all",   &s, &mix_st);

   double erg;
   int ie;
   for (ie=0; ie<=3000; ++ie) {
      erg = logScale(ie, 0.01, 1E6, 3000);
      fprintf(fp_mudr_st, "%E  %E  %E  %E  %E  %E  %E\n",
              erg,
              CalcMudr(&iac_st_coh, erg),
              CalcMudr(&iac_st_inc, erg),
              CalcMudr(&iac_st_pe,  erg),
              CalcMudr(&iac_st_pn,  erg),
              CalcMudr(&iac_st_pa,  erg),
              CalcMudr(&iac_st_all, erg));
   }  
   fclose(fp_mudr_st);
   FreeMudrCspMix(&iac_st_coh); 
   FreeMudrCspMix(&iac_st_inc);
   FreeMudrCspMix(&iac_st_pe);
   FreeMudrCspMix(&iac_st_pa);
   FreeMudrCspMix(&iac_st_pn);
   FreeMudrCspMix(&iac_st_all);
   printf("data written in 'test_mudr_st.dat'\n");
   //---------------------------------------------------------------------------

   FreeXdata(&s);
   FreeMix(&mix_st);
   return 0;
}
//------------------------------------------------------------------------------
