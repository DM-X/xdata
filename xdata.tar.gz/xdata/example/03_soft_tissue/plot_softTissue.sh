gnuplot test_F_st.plt
gnuplot test_Jtotal_st.plt
gnuplot test_S_st.plt
gnuplot test_mudr_st.plt
