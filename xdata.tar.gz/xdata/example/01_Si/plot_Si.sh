#!/bin/sh
gnuplot test_F_Si.plt
gnuplot test_J_Si.plt
gnuplot test_Jtotal_Si.plt
gnuplot test_S_Si.plt
gnuplot test_mudr_Si.plt
