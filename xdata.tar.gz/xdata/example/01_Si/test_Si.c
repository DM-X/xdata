#include <stdio.h>
#include <stdlib.h>
#include "../../xdata.h"

int main()
{
   //initialization reads the lengths of all lists and checks if all data can
   //be found
   xset_t s;
   if (InitXdata(&s, "../..")) {
      printf("ERR: initialization failed! Exit...\n");
      return 1;
   }
   printf("used path: %s\n", s.path_data);
   //---------------------------------------------------------------------------
   
   //using the rho_list 
   double* rho_list;
   double* rhoN_list;
   GetRho(&rho_list, &rhoN_list, NULL, &s);
   PrintRho(rho_list, rhoN_list, "14", &s);
   FreeRho(&rho_list, &rhoN_list);
   //---------------------------------------------------------------------------

   //using the A_list 
   double* A_list;
   GetA(&A_list, NULL, &s);
   PrintA(A_list, "14", &s);
   FreeA(&A_list);
   //---------------------------------------------------------------------------
   
   //using the ionization list in combination with the uncertainty
   double** I_list;
   double** deltaI_list;
   GetI(&I_list, &deltaI_list, NULL, NULL, &s);
   PrintI(I_list, deltaI_list, "Si");
   FreeI(&I_list, &deltaI_list, &s);
   //---------------------------------------------------------------------------

   //using the F_list 
   double** F_list;
   GetF(&F_list, NULL, NULL, &s);
   PrintF(F_list, "Si", &s);
   FreeF(&F_list, &s);
   //---------------------------------------------------------------------------

   //using the F cubic spline interpolation for an element
   printf("\nF CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_F_Si = fopen("test_F_Si.dat", "w");
   if (fp_F_Si==NULL) {printf("ERR: opening test_F_Si.dat\n"); exit(1);}
   double ergF   = 60;
   double thetaF = 90;
   fs_t F_Si;
   GetFCsp(&F_Si, "14", NULL, &s); 
   fprintf(fp_F_Si, "#E [keV]  theta [deg]  F []\n");
   int i;
   for (i=0; i<=100; ++i) {
      ergF = logScale(i, 0.01, 200, 100);
      fprintf(fp_F_Si, "%E  %E  %E\n",ergF, thetaF, CalcF(&F_Si, ergF, thetaF));
   }
   FreeFCsp(&F_Si);
   fclose(fp_F_Si);
   printf("data written in 'test_F_Si.dat'\n");
   //---------------------------------------------------------------------------
   
   //using the S_list 
   double** S_list;
   GetS(&S_list, NULL, NULL, &s);
   PrintS(S_list, "14", &s);
   FreeS(&S_list, &s);
   //---------------------------------------------------------------------------

   //using the S cubic spline interpolation
   printf("\nS CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_S_Si = fopen("test_S_Si.dat", "w");
   if (fp_S_Si==NULL) {printf("ERR: opening test_S_Si.dat\n"); exit(1);}
   double ergS   = 60;
   double thetaS = 90;
   fs_t S_Si;
   GetSCsp(&S_Si, "14", NULL, &s); 
   fprintf(fp_S_Si, "#E [keV]  theta [deg]  S []\n");
   int is;
   for (is=0; is<=100; ++is) {
      ergS = logScale(is, 0.01, 200, 100);
      fprintf(fp_S_Si, "%E  %E  %E\n",ergS, thetaS, CalcS(&S_Si, ergS, thetaS));
   }
   FreeSCsp(&S_Si);
   fclose(fp_S_Si);
   printf("data written in 'test_S_Si.dat'\n");
   //---------------------------------------------------------------------------
   
   //using the J_list
   double*** J_list; //[z][shell][data]
   int*      ns;        //nbr of shells [z:1..102] 
   int**     ne;        //nbr el in shell [z:1.102][shell:1..ns[z]]
   double**  be;        //binding energ [z:1..102][shell:1..ns[z]]
   GetJ(&J_list, &ns, &ne, &be, NULL, NULL, &s);
   PrintJ(J_list, ns, ne, be, "4", &s);
   PrintJ(J_list, ns, ne, be, "14", &s);
   //some checks on the J lists
   int nbr_of_errors = CheckJ(J_list, ns, ne, &s);
   printf("\nJ check: number of errors: %d\n", nbr_of_errors);
   FreeJ(&J_list, &ns, &ne, &be, &s);
   //---------------------------------------------------------------------------
   
   //using the J cubic spline interpolation -> shell compton profiles
   printf("\nJ SHELL CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_J_Si = fopen("test_J_Si.dat", "w");
   if (fp_J_Si==NULL) {printf("ERR: opening test_J_Si.dat\n"); exit(1);}
   cprof_t Jshells_Si;
   GetJShells(&Jshells_Si, "14", NULL, NULL, &s);
   printf("Jshells_Si nbr of shells = %d\n", Jshells_Si.nbr_shells);
   double E0 = 60;
   double E  = 50;
   double th = 91;
   fprintf(fp_J_Si, "#E [keV]      Q []         J_shell []\n");
   int ij;
   for (ij=0; ij<=200; ++ij) {
      E = linScale(ij, 30, 65, 200);
      fprintf(fp_J_Si,"%E  %E  %E\n", E, CalcQ(E0, th, E),
              CalcJShell(&Jshells_Si,3,E0,th,E));
   }
   FreeJShells(&Jshells_Si);
   fclose(fp_J_Si);
   printf("data written in 'test_J_Si.dat'\n");
   //---------------------------------------------------------------------------
   
   //using the J cubic spline interpolation -> total compton profiles
   printf("\nJ_TOTAL CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_Jtot_Si = fopen("test_Jtotal_Si.dat", "w");
   if (fp_Jtot_Si==NULL) {printf("ERR: opening test_Jtotal_Si.dat\n");exit(1);}
   acp_t Jtot_Si;
   MakeJTotal(&Jtot_Si, "14", &s);
   double EJ0   = 60;
   double EJ    = 50;
   double thJ   = 91.02;

   fprintf(fp_Jtot_Si, "#E [keV]      Q []         J_total []\n");
   int ija;
   for (ija=0; ija<=5000; ++ija) {
      EJ = linScale(ija, 30, 65, 5000);
      fprintf(fp_Jtot_Si,"%E  %E  %E\n", EJ, CalcQ(EJ0, thJ, EJ),
              CalcJTotal(&Jtot_Si, EJ0, thJ, EJ));
   }
   FreeJTotal(&Jtot_Si);
   fclose(fp_Jtot_Si);
   printf("data written in 'test_Jtotal_Si.dat'\n");
   //---------------------------------------------------------------------------

   //using the mu/rho_list
   mudr_t mudivrho;
   GetMudr(&mudivrho, "14", NULL, NULL, &s);
   PrintMudr(&mudivrho, -1, -1);
   FreeMudr(&mudivrho);
   //---------------------------------------------------------------------------

   //using the mu/rho_csp_list for an element
   printf("\nmu/rho MASS ATTENUATION COEFFICIENT CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_mudr_Si = fopen("test_mudr_Si.dat", "w");
   if (fp_mudr_Si==NULL) {printf("ERR: opening test_mudr_Si.dat\n");exit(1);}
   iac_t iac_Si_coh, iac_Si_inc, iac_Si_pe, iac_Si_pn, iac_Si_pa, iac_Si_all;
   GetMudrCsp(&iac_Si_coh, "Si", "coh",   NULL, &s);
   GetMudrCsp(&iac_Si_inc, "Si", "inc",   NULL, &s);
   GetMudrCsp(&iac_Si_pe,  "Si", "PE",    NULL, &s);
   GetMudrCsp(&iac_Si_pn,  "Si", "pairn", NULL, &s);
   GetMudrCsp(&iac_Si_pa,  "Si", "paira", NULL, &s);
   GetMudrCsp(&iac_Si_all, "Si", "all",   NULL, &s);

   PrintMudrCsp(&iac_Si_all);

   double erg = 600;
   printf("E=%f keV, mu/rho=%E cm^2/g\n", erg, CalcMudr(&iac_Si_all, erg));

   int ie;
   for (ie=0; ie<=1000; ++ie) {
      erg = logScale(ie, 0.01, 1E6, 1000);
      fprintf(fp_mudr_Si, "%E  %E  %E  %E  %E  %E  %E\n",
              erg,
              CalcMudr(&iac_Si_coh, erg),
              CalcMudr(&iac_Si_inc, erg),
              CalcMudr(&iac_Si_pe,  erg),
              CalcMudr(&iac_Si_pn,  erg),
              CalcMudr(&iac_Si_pa,  erg),
              CalcMudr(&iac_Si_all, erg));
   }
   FreeMudrCsp(&iac_Si_coh);
   FreeMudrCsp(&iac_Si_inc);
   FreeMudrCsp(&iac_Si_pe);
   FreeMudrCsp(&iac_Si_pn);
   FreeMudrCsp(&iac_Si_pa);
   FreeMudrCsp(&iac_Si_all);
   fclose(fp_mudr_Si);
   //---------------------------------------------------------------------------
   
   FreeXdata(&s);
   return 0;
}
//------------------------------------------------------------------------------
