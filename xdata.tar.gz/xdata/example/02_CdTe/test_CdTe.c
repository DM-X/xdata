#include <stdio.h>
#include <stdlib.h>
#include "../../xdata.h"

int main()
{
   //initialization reads the lengths of all lists and checks if all data can
   //be found
   xset_t s;
   if (InitXdata(&s, "../..")) {
      printf("ERR: initialization failed! Exit...\n");
      return 1;
   }
   printf("used path: %s\n", s.path_data);
   //---------------------------------------------------------------------------
   
   //using the rho_list 
   rho_t* rho_list;
   GetRhoComp(&rho_list, NULL, &s);
   printf("CdTe: rho = %f\n", GiveRhoComp(rho_list, "CdTe", &s));
   FreeRhoComp(&rho_list);
   //---------------------------------------------------------------------------

   //using the A_list
   // -> not defined for a compound
   //---------------------------------------------------------------------------
   
   //using the ionization list in combination with the uncertainty
   // -> not defined for a compound
   //---------------------------------------------------------------------------
   
   //using the F cubic spline interpolation for a compound
   printf("\nF CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_F_CdTe = fopen("test_F_CdTe.dat", "w");
   if (fp_F_CdTe==NULL) {printf("ERR: opening test_F_CdTe.dat\n"); exit(1);}
   double ergF   = 60;
   double thetaF = 90;
   fs_t F_CdTe;
   MakeFCspComp(&F_CdTe, &s, 2, "Cd", 1, "Te", 1); 
   int iF;
   fprintf(fp_F_CdTe, "#E [keV]  theta [deg]  F []\n");
   for (iF=0; iF<=100; ++iF) {
      ergF = logScale(iF, 0.01, 200, 100);
      fprintf(fp_F_CdTe, "%E %E %E\n", 
              ergF, thetaF, CalcF(&F_CdTe, ergF, thetaF));
   }
   FreeFCspComp(&F_CdTe);
   fclose(fp_F_CdTe);
   printf("data written in 'test_F_CdTe.dat'\n");
   //---------------------------------------------------------------------------

   //using the S cubic spline interpolation for a compound
   printf("\nS CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_S_CdTe = fopen("test_S_CdTe.dat", "w");
   if (fp_S_CdTe==NULL) {printf("ERR: opening test_S_CdTe.dat\n"); exit(1);}
   double ergS   = 60;
   double thetaS = 90;
   fs_t S_CdTe;
   MakeSCspComp(&S_CdTe, &s, 2, "Cd", 1, "Te", 1); 
   int iS;
   fprintf(fp_S_CdTe, "#E [keV]  theta [deg]  S []\n");
   for (iS=0; iS<=100; ++iS) {
      ergS = logScale(iS, 0.01, 200, 100);
      fprintf(fp_S_CdTe, "%E %E  %E\n", 
              ergS, thetaS, CalcS(&S_CdTe, ergS, thetaS));
   }
   FreeSCspComp(&S_CdTe);
   fclose(fp_S_CdTe);
   printf("data written in 'test_S_CdTe.dat'\n");
   //---------------------------------------------------------------------------
   
   //using the J cubic spline interpolation -> total compton profiles
   printf("\nJ_TOTAL CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_Jtot_CdTe = fopen("test_Jtotal_CdTe.dat", "w");
   if (fp_Jtot_CdTe==NULL) {printf("ERR: open test_Jtotal_CdTe.dat\n");exit(1);}
   acp_t Jtot_CdTe;
   MakeJTotalComp(&Jtot_CdTe, &s, 2, "Cd", 1, "Te", 1);
   double EJ0   = 60;
   double EJ    = 50;
   double thJ   = 91.02;

   fprintf(fp_Jtot_CdTe, "#E [keV]      Q []         J_total []\n");
   int ij;
   for (ij=0; ij<=5000; ++ij) {
      EJ = linScale(ij, 40, 65, 5000);
      fprintf(fp_Jtot_CdTe,"%E  %E  %E\n", EJ, CalcQ(EJ0, thJ, EJ),
              CalcJTotal(&Jtot_CdTe, EJ0, thJ, EJ));
   }
   FreeJTotalComp(&Jtot_CdTe);
   fclose(fp_Jtot_CdTe);
   printf("data written in 'test_Jtotal_CdTe.dat'\n");
   //---------------------------------------------------------------------------

   //using the mu/rho_csp_list for a compound
   printf("\nmu/rho MASS ATTENUATION COEFFICIENT CUBIC SPLINE INTERPOLATION:\n");
   FILE* fp_mudr_CdTe = fopen("test_mudr_CdTe.dat", "w");
   if (fp_mudr_CdTe==NULL) {printf("ERR: opening test_mudr_Si.dat\n");exit(1);}

   iac_t iac_CdTe_coh, iac_CdTe_inc, iac_CdTe_pe;
   iac_t iac_CdTe_pn, iac_CdTe_pa, iac_CdTe_all;
   MakeMudrCspComp(&iac_CdTe_coh, "coh",   &s, 2, "Cd", 1, "Te", 1);
   MakeMudrCspComp(&iac_CdTe_inc, "inc",   &s, 2, "Cd", 1, "Te", 1);
   MakeMudrCspComp(&iac_CdTe_pe,  "PE",    &s, 2, "Cd", 1, "Te", 1);
   MakeMudrCspComp(&iac_CdTe_pn,  "pairn", &s, 2, "Cd", 1, "Te", 1);
   MakeMudrCspComp(&iac_CdTe_pa,  "paira", &s, 2, "Cd", 1, "Te", 1);
   MakeMudrCspComp(&iac_CdTe_all, "all",   &s, 2, "Cd", 1, "Te", 1);

   double erg;
   int ie;
   for (ie=0; ie<=3000; ++ie) {
      erg = logScale(ie, 0.01, 1E6, 3000);
      fprintf(fp_mudr_CdTe, "%E  %E  %E  %E  %E  %E  %E\n",
              erg,
              CalcMudr(&iac_CdTe_coh, erg),
              CalcMudr(&iac_CdTe_inc, erg),
              CalcMudr(&iac_CdTe_pe,  erg),
              CalcMudr(&iac_CdTe_pn,  erg),
              CalcMudr(&iac_CdTe_pa,  erg),
              CalcMudr(&iac_CdTe_all, erg));
   }  
   fclose(fp_mudr_CdTe);
   FreeMudrCspComp(&iac_CdTe_coh); 
   FreeMudrCspComp(&iac_CdTe_inc);
   FreeMudrCspComp(&iac_CdTe_pe);
   FreeMudrCspComp(&iac_CdTe_pa);
   FreeMudrCspComp(&iac_CdTe_pn);
   FreeMudrCspComp(&iac_CdTe_all);
   printf("data written in 'test_mudr_CdTe.dat'\n");
   //---------------------------------------------------------------------------
   
   FreeXdata(&s);
   return 0;
}
//------------------------------------------------------------------------------
