gnuplot test_F_CdTe.plt
gnuplot test_Jtotal_CdTe.plt
gnuplot test_S_CdTe.plt
gnuplot test_mudr_CdTe.plt
