#include <stdio.h>
#include <stdlib.h>
#include "xdata.h"

int main()
{
   //initialization reads the lengths of all lists and checks if all data can
   //be found
   xset_t s;
   if (InitXdata(&s, ".")) {
      printf("ERR: initialization failed! Exit...\n");
      return 1;
   }
   printf("used path: %s\n", s.path_data);
   //---------------------------------------------------------------------------

   printf("Hello, xdata!\n");

   FreeXdata(&s);
   return 0;
}
